# Comprehensive Fix & Alignment for Single-Page CBC Report (`rptrchemcour.pdf`)

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix the empty results column by properly aggregating child test/parameter results in `reports.py` and `pdf_generator.py`, and align the visual formatting of the CBC dedicated page with `docs/reference/rptrchemcour.pdf` using Courier clinical typography, 3-column patient metadata, demographic reference categories, and single-page containment.

**Architecture:**
1. `backend/app/routers/reports.py`: Update `get_visit_report_pdf` to query and attach `parameters: [...]` for parent tests, and bundle all CBC child parameter test orders under the parent CBC test object so values, units, flags, and reference ranges are fully populated in `results_data`.
2. `backend/app/pdf_generator.py`: Overhaul `_build_cbc_table` and CBC page layout:
   - Use **Courier** and **Courier-Bold** font throughout the CBC table.
   - Reconstruct the 3-column clinical patient metadata box:
     - Col 1: `MC No : <val>`, `Dated : <val>`, `Ref. B : <val>`
     - Col 2: `Name : <val>`, `Age : <val>`, `Sex : <val>`
     - Col 3: `Lab No : <val>`, `Ward / OPD : <val>`, `Specimen : Blood`
   - Recreate the bordered `HAEMATOLOGY CBC REPORT` title box.
   - Add demographic category header (`Child` / `Adult`) positioned above `Ref. Ranges`.
   - Format the 22 parameters across the 4 sections with `-` dividers.
   - Recreate the bottom timestamp/date and technologist signature footer.
3. Tests & Verification: End-to-end PDF generation test validating populated text, column alignment, font choice, and strict 1-page count.

**Tech Stack:** Python 3.11+, ReportLab, SQLite, FastAPI, PyPDF.

**Spec:** `docs/reference/rptrchemcour.pdf`, `docs/BEST_PRACTICES.md`, `docs/nihon-kohden-analyzer-integration.md`.

## Global Constraints
- No emojis anywhere in UI, code, or PDFs (`docs/BEST_PRACTICES.md`).
- Multi-parameter tests (CBC, Urinalysis) must fit strictly on their own dedicated single page (`docs/BEST_PRACTICES.md`).
- Results and flags must be properly populated and aligned.

---

### Task 1: Fix Parameter Aggregation in `backend/app/routers/reports.py` and `backend/app/pdf_generator.py`

**Files:**
- Modify: `backend/app/routers/reports.py`
- Modify: `backend/app/pdf_generator.py`
- Test: `tests/test_pdf_cbc_report.py`

**Interfaces:**
- `get_visit_report_pdf(visit_id: int, ...)`
- `generate_pdf(order_data: dict, results_data: list) -> bytes`

- [ ] **Step 1: Write test in `tests/test_pdf_cbc_report.py` verifying populated values from child orders and parameter results**
Test that `generate_pdf` correctly extracts values when passed child test orders or `parameters` array, and verify all 22 result values appear in the PDF text stream via `pypdf`.

- [ ] **Step 2: Update `backend/app/routers/reports.py`**
  - When querying visit test orders, identify if tests belong to a multi-parameter parent (e.g. `parent_rollup_id` or child CBC orders).
  - Also query `parameter_results` table for orders that store sub-parameter rows.
  - Attach `parameters` array to the parent test object in `results_data`.

- [ ] **Step 3: Update `backend/app/pdf_generator.py` to aggregate CBC child tests if passed as separate list items**
  - In `generate_pdf`, if individual CBC parameter tests are present in `tests` (e.g. "Total WBC Count", "Hemoglobin (Hb)", "Neutrophils (%)"), aggregate them into `cbc_test["parameters"]` so values are never lost regardless of whether the caller bundles them or lists them individually.

- [ ] **Step 4: Run tests**
Run `python -m pytest tests/test_pdf_cbc_report.py -v`.

---

### Task 2: Recreate Exact `rptrchemcour.pdf` Visual Layout & Courier Typography in `pdf_generator.py`

**Files:**
- Modify: `backend/app/pdf_generator.py`
- Test: `tests/test_pdf_cbc_report.py`

- [ ] **Step 1: Implement 3-column clinical patient metadata header**
```python
def _build_cbc_patient_header(order_data: dict) -> Table:
    # 3 columns:
    # Col 1: MC No, Dated, Ref. B
    # Col 2: Name, Age, Sex
    # Col 3: Lab No, Ward / OPD, Specimen (Blood)
```
Style with `Courier` / `Courier-Bold`, 8.5pt.

- [ ] **Step 2: Implement Courier table layout with demographic category and exact section dividers**
  - Use `Courier` font for values/units/ranges and `Courier-Bold` for test names and abnormal flags.
  - Column header: `Test`, `Result`, `Units`, `Flag`, `Ref. Ranges` with demographic label (`Child` if age < 18 else `Adult`) aligned over `Ref. Ranges`.
  - Divider lines `-` between the 4 sections:
    1. Main Indices (8 parameters)
    2. Relative Differential (%) (5 parameters)
    3. Absolute Differential (10^9/uL) (5 parameters)
    4. RBC & Platelet Indices (4 parameters)
  - Footer with analyzer / visit timestamp, date, and `Technologist Signature` line.

- [ ] **Step 3: Verify single-page containment**
Assert that the entire CBC page (letterhead + 3-col header + title box + 22 rows + dividers + footer) occupies exactly 1 page.

- [ ] **Step 4: Run full test suite**
Run `python -m pytest -v`.

---

## Verification Plan

### Automated Tests
```bash
python -m pytest tests/test_pdf_cbc_report.py -v
python -m pytest tests/test_nihon_kohden_parser.py -v
python -m pytest tests/test_integrations_api.py -v
python -m pytest -v
```

### Manual Visual Verification
Generate a test PDF and convert/inspect visual screenshot to confirm 100% visual match with `docs/reference/rptrchemcour.pdf`.
