# Nihon Kohden EXP Reference Ranges & Single-Page PDF Layout Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Surgically update `nihon_kohden.py` to extract low-high reference intervals from the `EXP` record as `reference_range` metadata on each parameter, and update `pdf_generator.py` to dynamically use these ranges, incorporate test timestamps/metadata, and guarantee strict single-page fit for dedicated CBC reports matching `docs/reference/rptrchemcour.pdf`.

**Architecture:** 
1. `backend/app/parsers/nihon_kohden.py`: Surgically extract the `EXP` record stream (Mode 1 and Mode 2), parse the 22 low/high numeric limit pairs, and attach `reference_range` string (e.g. `"4.0 - 9.0"`) to each corresponding parameter dictionary.
2. `backend/app/pdf_generator.py`: Update `_build_cbc_table` to pull dynamic `reference_range` from result entries, incorporate analyzer timestamp metadata, and tune table padding and row heights so the entire CBC report fits within exactly 1 dedicated page.
3. Tests: Update parser and PDF test suites to verify `reference_range` extraction and assert strict single-page PDF output.

**Tech Stack:** Python 3.11+, ReportLab 3.x/4.x, FastAPI, Pytest.

**Spec:** `docs/nihon-kohden-analyzer-integration.md`, `docs/BEST_PRACTICES.md`, `docs/reference/rptrchemcour.pdf`.

## Global Constraints
- No emojis anywhere in code, comments, docs, or UI (`docs/BEST_PRACTICES.md`).
- Multi-parameter tests (CBC, Urinalysis) must fit strictly on their own single dedicated page without overlapping other tests or spilling onto a second page (`docs/BEST_PRACTICES.md`).
- Surgical changes only: preserve existing `parse_nihon_kohden_output` return structure, adding `reference_range` to each parameter object without breaking existing keys (`name`, `value`, `flag`, `unit`).
- Keep existing AMH Lab Tracker digital signature block and letterhead styling.

---

### Task 1: Surgical Extraction of `EXP` Reference Ranges in `nihon_kohden.py`

**Files:**
- Modify: `backend/app/parsers/nihon_kohden.py`
- Test: `tests/test_nihon_kohden_parser.py`

**Interfaces:**
- `parse_nihon_kohden_output(raw_text: str) -> Dict[str, Any]`
- Return format for each parameter in `parameters` list:
  ```python
  {
      "name": "Red Blood Cells (RBC)",
      "value": "6.92",
      "flag": "H",
      "unit": "10⁶/µL",
      "reference_range": "3.76 - 5.70"
  }
  ```

- [ ] **Step 1: Write failing tests in `tests/test_nihon_kohden_parser.py`**
Add test assertions verifying that `reference_range` is extracted for all 22 parameters from `nihon output.txt` (e.g. WBC: `"4.0 - 9.0"`, RBC: `"3.76 - 5.70"`, Hb: `"12.0 - 18.0"`, PLT: `"150 - 350"`).

- [ ] **Step 2: Run test to verify failure**
Run `pytest tests/test_nihon_kohden_parser.py -k test_exp_reference_ranges` and verify it fails (missing `reference_range` key).

- [ ] **Step 3: Implement surgical `_extract_exp_ranges()` in `nihon_kohden.py`**
  - In `_extract_fields(raw_text)`: Return both `(patient_fields, exp_fields)`.
  - In `_extract_exp_ranges(exp_fields)`: Extract pairs of low/high float/int tokens for the 22 sequential parameters.
  - In `parse_nihon_kohden_output()`: Attach `reference_range` to each of the 22 parameter objects.

- [ ] **Step 4: Run parser unit tests to verify they pass**
Run `pytest tests/test_nihon_kohden_parser.py -v`.

---

### Task 2: Enhance `pdf_generator.py` for Dynamic Reference Ranges & Strict Single-Page Fit

**Files:**
- Modify: `backend/app/pdf_generator.py`
- Test: `tests/test_pdf_cbc_report.py`

**Interfaces:**
- `_build_cbc_table(order_data: dict, cbc_test: dict) -> List[Flowable]`
- `generate_pdf(order_data: dict, results_data: list) -> bytes`

- [ ] **Step 1: Write test in `tests/test_pdf_cbc_report.py` verifying dynamic ranges and single-page constraint**
Verify that a CBC report with 22 results containing dynamic `reference_range` values outputs a valid PDF with exactly 1 page (or dedicated page if part of multi-test order) and does not spill.

- [ ] **Step 2: Update `_build_cbc_table()` in `pdf_generator.py`**
  - Read `item.get("reference_range")` or `item.get("reference")` from result object before falling back to default range.
  - Include Analyzer Analysis Timestamp (if present in `order_data` or `cbc_test` metadata) in a compact subheader above the CBC table.
  - Tune table row heights (`colWidths=[160, 65, 75, 50, 110]`), vertical table cell padding (`TOPPADDING=2`, `BOTTOMPADDING=2`), font size (8.5pt / 8pt), and spacer heights so that Header + Client Meta + 22 CBC Rows + 3 Section Dividers + Timestamps + Signatures strictly occupy $\le 720\text{pt}$ (A4 printable area).

- [ ] **Step 3: Run PDF generator tests**
Run `pytest tests/test_pdf_cbc_report.py -v`.

---

### Task 3: Full Integration Test Verification

**Files:**
- Modify: `tests/test_integrations_api.py`

- [ ] **Step 1: Test API endpoint `/api/integrations/parse-analyzer-output`**
Verify the API response contains `reference_range` on each parameter in `parameters` array.

- [ ] **Step 2: Run full project test suite**
Run `pytest -v` across all test files to ensure 100% pass rate.

## Verification Plan

### Automated Tests
```bash
pytest tests/test_nihon_kohden_parser.py -v
pytest tests/test_pdf_cbc_report.py -v
pytest tests/test_integrations_api.py -v
pytest
```

### Manual Verification
1. Generate sample PDF using `python scratch/test_generate_cbc.py` with `nihon output.txt` parsed data.
2. Verify page count is strictly 1 and layout matches `docs/reference/rptrchemcour.pdf`.
