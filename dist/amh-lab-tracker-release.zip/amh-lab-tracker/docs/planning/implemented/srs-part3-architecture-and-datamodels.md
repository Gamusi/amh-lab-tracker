# Software Requirements Specification (SRS) — Part 3
## AMH Lab Tracker — System Architecture & Database Design

---

### 1. System Tech Stack & Environment Constraints

The **AMH Lab Tracker** is architected to perform seamlessly under stringent local hardware limitations [516, 524] while maintaining full portability and forward-compatibility with modern operating systems and potential future cloud/containerized deployments [user query].

#### 1.1 Core Backend & Shell Runtime
*   **Application Language:** Python 3.11+ [423, 424].
*   **Web Server Framework:** FastAPI [516, 519]. FastAPI is selected for its high execution speed, automatic OpenAPI documentation, and minimal memory footprint.
*   **ASGI Server:** Uvicorn [516, 519]. Runs as a lightweight local background daemon.
*   **Local Desktop Container:** `pywebview` [516, 518] (Python desktop shell wrapping Edge WebView2 on Windows or WebKitGTK on Linux).
*   **Unconditional Browser Fallback:** If PyWebView initialization fails due to legacy graphics drivers or missing native OS web components [516], the launcher automatically triggers `webbrowser.open()` [518] to launch the user's default browser (e.g., Chrome, Edge, Firefox) pointed to localhost [518, 524].
*   **No-Cloud Isolation:** The app operates 100% offline [516], binding exclusively to the local loopback adapter (`127.0.0.1`) at port `8756` [516, 524]. This provides an impenetrable hardware-level firewall against cross-network eavesdropping over local Wi-Fi or LAN [524].

#### 1.2 Target Hardware & Compatibility Tuning
To accommodate Ahmadiyya Muslim Hospital Mbale's low-specification computers (Intel Core 2 Duo era, 2GB RAM) [423, 516, 524], the application is tuned with the following constraints:
*   **Process Isolation:** The Python FastAPI backend runs as a single-threaded local process with minimal active workers, consuming less than **50MB of RAM** at rest.
*   **No Developer-Mode Overhead:** Development flags such as Uvicorn's `reload=True` are strictly disabled in production [524]. This eliminates continuous file-system scanning and directory watching, which would saturate legacy hard drive I/O and freeze the system [524].
*   **Offline Dependencies:** All application dependencies are packaged as pre-compiled Python wheel (`.whl`) files stored in `usb_drive/wheels/` [390, 421] to allow zero-network installations on air-gapped host machines [516, 521].

---

### 2. Database Engine: SQLite with WAL (Write-Ahead Logging)

To achieve maximum data integrity and reliable concurrent operation without the resource overhead of heavy client-server database engines (like PostgreSQL) [545], the system utilizes **SQLite** [421, 516]. 

By default, SQLite locks the entire database file during write transactions, which can cause "Database Is Locked" errors if multiple browser tabs or background operations attempt to write at the same time [srs part 3 queries]. To solve this, the AMH Lab Tracker must run in **Write-Ahead Logging (WAL) Mode** [user query, srs part 3 queries].

#### 2.1 WAL Mode Mechanics
*   **Concurrent Reads/Writes:** In WAL mode, writes do not block readers, and readers do not block writes [srs part 3 queries]. This ensures that while a technician is saving a large daily batch log, another view can concurrently run intensive trend queries or generate reports without experiencing system freezes [user query].
*   **Performance:** WAL mode is significantly faster for database writes because modifications are appended to a separate, high-speed `-wal` journal file on disk rather than directly replacing blocks in the primary `.db` file.
*   **Foreign Key Enforcement:** Foreign keys are explicitly turned on for every connection to guarantee relational integrity [521].

#### 2.2 Connection Factory Implementation
The database connection factory (`backend/app/database.py`) must enforce WAL mode and relational integrity during initialization [521]:

```python
import sqlite3
import os

DB_DIR = "/workspace/data" # Configured for production paths
DB_PATH = os.path.join(DB_DIR, "amh_lab.db")

def get_connection():
    # Ensure database directory exists
    os.makedirs(DB_DIR, exist_ok=True)
    
    # Establish base connection
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    
    # Enable relational constraints and WAL concurrency
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    
    return conn

def get_db():
    conn = get_connection()
    conn.row_factory = sqlite3.Row # Returns dict-like rows for easy JSON serialization
    try:
        yield conn
    finally:
        conn.close()
```

---

### 3. Refactored Relational Database Schema & Data Models

To align the codebase with clean domain-driven laboratory practices, the schema has been fully refactored to replace legacy `patients` terminology with the **`clients`** domain vocabulary [524, 527]. All diagnostic services are recorded for "Clients" rather than assuming clinical sickness [524].

```mermaid
erDiagram
    clients ||--o{ test_orders : places
    sections ||--|{ tests : groups
    tests ||--o{ test_parameters : defines
    tests ||--o{ daily_entries : tracks
    test_orders ||--|{ test_results : contains
    test_parameters ||--o{ test_results : validates
    users ||--o{ test_orders : orders
    users ||--o{ test_results : records
    users ||--o{ user_sessions : authenticates
```

#### 3.1 Relational SQLite Schema (`schema.sql`)
The database initialize routines executes the following strict schema:

```sql
BEGIN TRANSACTION;

-- 1. User Management & Authorization
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'technician', -- 'admin', 'technician'
    is_active BOOLEAN NOT NULL DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS user_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id),
    token TEXT UNIQUE NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 2. Client Registry (Refactored from Patients)
CREATE TABLE IF NOT EXISTS clients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_number TEXT UNIQUE NOT NULL, -- Format: AMH-CL-YYYY-NNNN
    full_name TEXT NOT NULL,
    date_of_birth DATE,
    sex TEXT CHECK(sex IN ('Male', 'Female', 'Other')),
    phone TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 3. Laboratory Catalog Configuration
CREATE TABLE IF NOT EXISTS sections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL, -- e.g., Parasitology, Hematology, Biochemistry
    sort_order INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS tests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    section_id INTEGER NOT NULL REFERENCES sections(id),
    is_tracked BOOLEAN NOT NULL DEFAULT 0, -- Active for aggregated daily log tracking
    is_active BOOLEAN NOT NULL DEFAULT 1,  -- Enabled in test catalog
    sort_order INTEGER DEFAULT 0,
    parent_rollup_id INTEGER REFERENCES tests(id), -- For hierarchical test groups
    UNIQUE(name, section_id)
);

CREATE TABLE IF NOT EXISTS test_parameters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    test_id INTEGER NOT NULL REFERENCES tests(id) ON DELETE CASCADE,
    parameter_name TEXT NOT NULL, -- e.g., Hemoglobin, WBC Count, RBC Count
    unit TEXT,                    -- e.g., g/dL, x10^9/L
    ref_range TEXT,               -- Reference limits representation
    sort_order INTEGER DEFAULT 0
);

-- 4. Clinical Workflow Transactions
CREATE TABLE IF NOT EXISTS test_orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER NOT NULL REFERENCES clients(id),
    test_id INTEGER NOT NULL REFERENCES tests(id),
    sample_id TEXT, -- Physical collection tube unique barcode or ID
    ordered_by_user_id INTEGER REFERENCES users(id),
    ordered_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'completed', 'verified'))
);

CREATE TABLE IF NOT EXISTS test_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL REFERENCES test_orders(id) ON DELETE CASCADE,
    parameter_id INTEGER REFERENCES test_parameters(id) ON DELETE CASCADE,
    result_value TEXT,            -- Supports alphanumeric values (e.g., '12.4', 'Positive')
    is_positive BOOLEAN,          -- For rapid alert queries and positive counts
    entered_by_user_id INTEGER REFERENCES users(id),
    entered_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    verified_by_user_id INTEGER REFERENCES users(id),
    verified_at DATETIME
);

-- 5. Legacy/Aggregated Daily Entries Log (Optional Rollup)
CREATE TABLE IF NOT EXISTS daily_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_date DATE NOT NULL,
    test_id INTEGER NOT NULL REFERENCES tests(id),
    done INTEGER NOT NULL DEFAULT 0,
    positive INTEGER DEFAULT 0,
    entered_by_user_id INTEGER REFERENCES users(id),
    entered_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by_user_id INTEGER REFERENCES users(id),
    updated_at DATETIME,
    UNIQUE(entry_date, test_id)
);

-- 6. Central Audit Trail (Immutable)
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER REFERENCES users(id),
    action TEXT NOT NULL, -- e.g., 'SAVE_RESULT', 'AMEND_RESULT', 'DELETE_CLIENT'
    detail TEXT,         -- Secure JSON payload containing old_value and new_value
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

COMMIT;
```

---

### 4. Selectable PDF Export Engine (ReportLab)

To support the delivery of official clinical test results to clients as digital softcopies or professional printouts [user query], the AMH Lab Tracker integrates a dedicated, purely local, and portable PDF generation engine [user query, 423, 424].

#### 4.1 Selection Criteria: Why ReportLab?
*   **Vector-Based Selectable Text:** Native PDF generation ensures that all text (client names, dates, results) is completely vector-based and selectable [user query]. This allows medical officers or external labs to copy, search, and verify text values directly within the PDF, avoiding the blurry, un-copyable look of image-rendered or screenshot-based PDFs.
*   **Zero OS Dependencies:** Unlike tools like `WeasyPrint` or `wkhtmltopdf` (which require external system libraries such as WebKit, GTK, Pango, or active X-servers), **ReportLab** is a pure Python library [423, 424]. It is bundled directly into our USB wheel files [390, 421] and runs smoothly on ancient Windows XP/7/10 machines with zero external software configurations.
*   **Dynamic Fallback Print Layout:** As a failsafe, the frontend SPA also exposes a clean, minimalist CSS print layout (`@media print` in `style.css`) that leverages the host browser's system print dialog. This provides technicians with a zero-dependencies print path if ReportLab compilation runs into localized OS system locks.

#### 4.2 Clinical PDF Layout & Standard Compliance
In strict compliance with **ISO 15189 (Clause 7.4.1 / Sustaining Standard LIMS S7)** regarding report contents and accuracy [169, 170, 264, 443], each compiled PDF report contains:
1.  **Laboratory Header & Branding:** Printed Ahmadiyya Muslim Hospital Letterhead, contact details, and clinical section logo.
2.  **Double-Identifier Client Information:** Complete Client Name, Date of Birth, Age, Sex, and Unique Client Number [198, 201, 203, 264].
3.  **Comprehensive Order Metadata:** Date and exact hour of sample collection, date received by laboratory, and date/time of report validation [265, 266].
4.  **Codified Test Results:** Clear parameters list with units, numerical or qualitative values, and **automatically highlighted abnormal/critical flags** [266, 273].
5.  **Reference Intervals:** Dynamic display of normal and critical reference intervals based on client age and biological sex [224, 225, 261, 266].
6.  **Immutable Signatures:** Actual full name and system ID of the performing technician and the verifying supervisor [258, 266].

---

### 5. Nihon Kohden Hematology Analyzer Integration Design

The hospital laboratory utilizes a **Nihon Kohden Hematology Analyzer** to run Complete Blood Counts (CBC). Interfacing clinical instruments dynamically is the gold standard under international LIMS guidelines to eliminate pre-analytical transcription errors [428, 430].

The analyzer exports data in two formats: **Vector PDF Reports** and **Raw Plain-Text SQL Strings** (for manual copying and database pasting) [user query].

#### 5.1 Contrast Analysis: Choosing the Integration Method

| Metric | Option A: PDF Scraping / Folder Drop | Option B: Raw SQL Plain-Text Clipboard Parser |
| :--- | :--- | :--- |
| **Concept** | System automatically monitors a local directory for exported analyzer PDFs, reading coordinates to extract blood values [user query]. | Technicians copy the plain-text SQL string from the analyzer screen/software, paste it into an import box, and hit "Parse" [user query]. |
| **Rigor & Stability** | **Extremely Fragile.** Coordinate-based scraping (e.g., extracting WBC at X=100, Y=250) breaks completely if the analyzer software gets updated, the formatting margins shift slightly, or a column moves. | **Highly Robust.** SQL text strings contain structured key-value pairs (e.g., `INSERT INTO results (WBC, RBC) VALUES (7.2, 4.5)`). String parsing is predictable and structurally independent of visual margins. |
| **Computational Overhead** | **High.** Extracting layout blocks and parsing fonts requires heavy OCR or complex Python PDF processing libraries (e.g., `pdfplumber`), slowing down 2GB RAM computers. | **Zero.** Simple string parsing and RegEx evaluation require virtually no processing power, executing in less than **5 milliseconds** on any machine. |
| **Deployment Effort** | **Complex.** Requires setting up OS-level folder-watching daemons, directory permissions, and robust handling of partial or corrupt file transfers. | **Incredibly Simple.** A lightweight, standard HTML `textarea` element on the frontend connected to a single FastAPI regex endpoint. |
| **Recommendation** | **Rejected** for Phase 1. High risk of breaking during normal clinical operations in Mbale. | **Approved for Implementation.** Safe, lightning-fast, highly predictable, and perfectly robust. |

#### 5.2 Semi-Automated Analyzer Clipboard Portal Architecture
To execute Option B safely, we design the **"Nihon Kohden Clipboard Portal"**:

1.  **Frontend Interface:** In the "Create Test Order" screen under Hematology (CBC), a text area labeled **"Import Analyzer Data (Plain-Text SQL)"** is exposed.
2.  **Paste Action:** The technician opens the analyzer logs, copies the raw plain text generated by the Nihon Kohden software, pastes it into the area, and clicks **"Process Import"**.
3.  **FastAPI Parser Endpoint (`POST /api/patients/analyzer-import`):**
    The backend receives the text. Using a safe Regex parser that handles SQL inserts or HL7-style plain text, it parses the key diagnostic hematology values:
    *   `WBC` (White Blood Cells)
    *   `RBC` (Red Blood Cells)
    *   `HGB` (Hemoglobin)
    *   `HCT` (Hematocrit)
    *   `PLT` (Platelets)
4.  **Auto-Population:** The endpoint returns these parsed values as structured JSON:
    ```json
    {
      "WBC": 7.2,
      "RBC": 4.5,
      "HGB": 13.5,
      "HCT": 41.2,
      "PLT": 250
    }
    ```
    The frontend JavaScript automatically injects these numbers into the corresponding test parameter input fields. The technician verifies the values visually against the printout and clicks "Save" to commit them to the database. This provides **double-keying equivalent validation** with zero manual transcription fatigue [173]!
