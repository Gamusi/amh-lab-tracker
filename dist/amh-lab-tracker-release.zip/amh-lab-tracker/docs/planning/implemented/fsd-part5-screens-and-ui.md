# Functional Specification Document (FSD) — Part 5
## AMH Lab Tracker — Desktop Laboratory System
**Ahmadiyya Muslim Hospital (AMH) — Mbale, Uganda**

---

### 1. Navigation & Application Shell (Top Navigation Bar)

To maximize vertical and horizontal screen real estate on Mbale's legacy monitors (typically 4:3 or low-resolution 16:9 displays) and support the laboratory's "simplicity that works" design philosophy, the **AMH Lab Tracker** utilizes a flat, persistent **Top Navigation Bar** instead of a heavy, collapsible sidebar [user query].

#### 1.1 Structural Layout
```
+--------------------------------------------------------------------------------------------------+
| [Logo] AMH LAB TRACKER  [ Clients ]  [ Daily Log ]  [ Verification ]  [ Test Menu ]  [ Reports ]  |
| (Active Tech: Gamusi)                                                       [Inactivity: 12:45] [Logout] |
+--------------------------------------------------------------------------------------------------+
|                                                                                                  |
|                                     ACTIVE SCREEN CONTAINER                                      |
|                                                                                                  |
+--------------------------------------------------------------------------------------------------+
```

#### 1.2 Layout & Behavior Rules
*   **Header Section**: 
    *   **Fixed Height**: 50px high, persistent across all views to eliminate visual jumping during navigation [519].
    *   **Brand Integrations**: Small institutional logo (32px x 32px) on the far left, followed by the system title in a clean sans-serif font [519].
    *   **Navigation Links**: Centered, high-contrast text tabs with minimal padding [user query]. The currently active tab is marked with a solid bottom-border (primary medical brand color) [538]. Hover states apply a light background highlight to ensure tactile feedback.
    *   **User & Session Status**: Positioned on the far right. Displays the logged-in user's full name (e.g., *"Gamusi"*) [532], their assigned role, an inactive countdown timer showing seconds remaining before auto-logout (starting at `15:00`), and a dedicated flat **Logout** button [532, 538].
*   **Active Screen Container**: Takes up 100% of the remaining viewport height. Uses native browser scrolling rather than complex layout scripts to keep RAM consumption at an absolute minimum [524, 538].
*   **CSS-Based Theme Integration**: The layout uses browser-native media queries to match system preferences (`@media (prefers-color-scheme: dark)`) [user query]. 
    *   *Default (Light)*: Clean white background (`#FFFFFF`), neutral slate borders (`#E2E8F0`), and dark charcoal text (`#1E293B`) to reduce glare under fluorescent laboratory lighting.
    *   *Dark Option (Automatic)*: Dark slate background (`#0F172A`), off-white text (`#F1F5F9`), and borders (`#334155`). No manual theme toggles are rendered to avoid unnecessary JS parsing overhead [user query].

---

### 2. Screen 1: Client Registration & Directory

To implement the strict **Domain-Driven Design (DDD)** shift from "Patients" to **"Clients"**, this screen is engineered to manage client profiles [524, 528]. Clients are registered once and can have multiple subsequent test orders, preventing redundant data entry [529].

#### 2.1 UI Layout & Wireframe Blueprint
```
+--------------------------------------------------------------------------------------------------+
|  CLIENT DIRECTORY                                                 [ + Register New Client ]      |
|  +----------------------------------------------------------+  +-------------------------------+  |
|  | Search Name or Client ID Number...                 [Search]|  | REGISTER CLIENT               |  |
|  +----------------------------------------------------------+  | Name: [                     ] |  |
|                                                                | IP No/ID: [                 ] |  |
|  +----------------------------------------------------------+  | DOB:  [ YYYY-MM-DD  ] [Age: ] |  |
|  | Client ID    | Full Name       | Sex | DOB       | Action |  | Sex:  ( ) Male  ( ) Female     |  |
|  +--------------+-----------------+-----+-----------+--------+  | Phone: [                    ] |  |
|  | AMH-2026-001 | Lucy Kemigisha  | F   | 1994-05-12| [Order]|  |                               |  |
|  | AMH-2026-002 | Ronald Mukasa   | M   | 2011-08-23| [Order]|  | [Cancel]       [Save Client]  |  |
|  +----------------------------------------------------------+  +-------------------------------+  |
+--------------------------------------------------------------------------------------------------+
```

#### 2.2 Client Search & Table Interaction
*   **The Directory Table**: Lists registered clients with their unique **Client ID** (formatted as `AMH-YYYY-NNNN`), Full Name, Sex, Date of Birth, and Contact Number [528].
*   **Active Directory Search**: A text-input box bound to an `oninput` handler in JS. Searching triggers an asynchronous request to `/api/clients?query=...` with a 150ms debounce window [529]. If the query is empty, it defaults to the latest 50 registered clients to avoid pulling a massive database payload into the browser [521, 525].
*   **Action Column**: Each row contains a direct button: **[New Order]**, which opens Screen 2 with that client's profile pre-loaded.

#### 2.3 Single-Screen Quick Registration Form
To support high-throughput clinical queues, the registration form is hosted as a collapsible panel on the right of the directory [519]:
*   **Client Name**: Capitalized automatically via CSS (`text-transform: uppercase`) to ensure database consistency.
*   **Client Number Input**: Unique identifier (e.g., outpatient IP number or national ID) [200].
*   **Dynamic DOB & Age Calculator**: Techs can enter either a strict Date of Birth (via a standard date picker) OR type the client's current age in years [201]. If Age is entered, the JS backend calculates a mock birth date (e.g., setting birth date to July 1st of the calculated year) to satisfy database schema consistency [528].
*   **Required Fields**: Full Name, Sex, and Client Number [200]. If a user clicks Save with these empty, the system flashes a red warning outline around the missing inputs without throwing database integrity exceptions.

---

### 3. Screen 2: Test Result Entry & Autoverification

This is the technician's primary workbench. It handles client validation, test ordering, and immediate results logging [518, 525]. It operates completely paperless: **a test cannot be run or printed without first logging the client and result in the system** [user query].

#### 3.1 UI Layout & Wireframe Blueprint
```
+--------------------------------------------------------------------------------------------------+
|  CLIENT: LUCY KEMIGISHA (F, 32Y)  |  ID: AMH-2026-001                                            |
|  +--------------------------------------------------------------------------------------------+  |
|  | SELECT SECTION / DEPARTMENT: [ Hematology           v]                                     |  |
|  | SELECT TEST TO ORDER:        [ Complete Blood Count (CBC)                           v] [Add] |  |
|  +--------------------------------------------------------------------------------------------+  |
|                                                                                                  |
|  ACTIVE TESTS WORKBENCH                                                                          |
|  +--------------------------------------------------------------------------------------------+  |
|  | Parameter Name | Value Entered | Reference Range | Alert Status       | Evaluation Mode    |  |
|  +----------------+---------------+-----------------+--------------------+--------------------+  |
|  | RBC            | [ 3.8       ] | 4.1 - 5.1       | [!] Low            | LIMS_EVALUATED     |  |
|  | Hemoglobin     | [ 11.2      ] | 12.0 - 15.5     | [!] Low            | LIMS_EVALUATED     |  |
|  | WBC            | [ 10.4      ] | 4.0 - 11.0      | Normal             | DEVICE_PRESET      |  |
|  | Platelets      | [ 92        ] | 150 - 450       | [!!] CRITICAL LOW  | LIMS_EVALUATED     |  |
|  +----------------+---------------+-----------------+--------------------+--------------------+  |
|  | Analyzer Clipboard Portal (Raw SQL Paste for Nihon Kohden):                                |  |
|  | [ INSERT INTO cbc_raw_results (rbc, hb, wbc, plt) VALUES (3.8, 11.2, 10.4, 92);          ]  |  |
|  +--------------------------------------------------------------------------------------------+  |
|  [Delete Order]                                                        [Submit and Queue for Ver] |
+--------------------------------------------------------------------------------------------------+
```

#### 3.2 Dynamic Laboratory Department Selection
*   **Department/Section Dropdown**: Groups tests by physical laboratory sections (e.g., Parasitology, Hematology, Biochemistry) [528]. Selecting a department filters the "Test to Order" list to show only relevant assays.
*   **Test Selection**: Technicians select a test (e.g., *Malaria Microscopy*, *CBC*, *LFT*) and click **[Add]** [528]. This generates the required rows in the `test_orders` and `test_results` tables in the background via POST `/api/orders` [528].

#### 3.3 Keyboard-Only Result Entry (Batch & Real-Time)
To facilitate rapid batch-entry of lab books, the result entry fields are optimized for rapid keyboard transcription [user query, 519]:
*   **Tab-Sequence Navigation**: Pressing `Tab` moves focus vertically down through parameters (e.g., from RBC -> Hemoglobin -> WBC -> Platelets) rather than jumping horizontally across options.
*   **Numerical Validation**: Inputs are bound to a strict numeric filter. If a technician types a non-numerical character (e.g., "12.O" instead of "12.0"), a red warning glow surrounds the input, and saving is disabled.
*   **The Clipboard Portal (Nihon Kohden Integration)**: For CBC tests run on the Nihon Kohden hematology analyzer, technicians do not need to manually transcribe values [user query]. They click inside the "Analyzer Clipboard Portal" text box, paste the raw plain-text SQL string exported by the analyzer, and click **Import** [user query]. The application's JavaScript runs a RegEx parsing routine in milliseconds, extracts the numeric parameters, maps them to the corresponding fields, and visually flashes the parsed values in green to confirm successful import [521, 538].

---

### 4. Screen 3: Test Verification and Release Screen

To comply with **ISO 15189 Clause 7.3** (verification of results prior to release) and **FDA 21 CFR Part 11** electronic signature standards, the system implements a strict **Verification Component** [3, 23, 258]. Entering a result does not authorize it for printing; it must be formally reviewed and released [user query, 258].

#### 4.1 UI Layout & Wireframe Blueprint
```
+--------------------------------------------------------------------------------------------------+
|  PENDING VERIFICATION QUEUE                                                                      |
|  +--------------------------------------------------------------------------------------------+  |
|  | Client Name     | Test Ordered | Entered By   | Time Logged         | Action               |  |
|  +-----------------+--------------+--------------+---------------------+----------------------+  |
|  | Lucy Kemigisha  | CBC          | Tech1 (John) | 2026-08-16 08:05    | [Review and Verify]  |  |
|  | Ronald Mukasa   | Malaria blood| Tech1 (John) | 2026-08-16 08:12    | [Review and Verify]  |  |
|  +-----------------+--------------+--------------+---------------------+----------------------+  |
|                                                                                                  |
|  VERIFICATION REVIEW PANEL: CLIENT LUCY KEMIGISHA                                                |
|  +--------------------------------------------------------------------------------------------+  |
|  | Parameter  | Value Entered | Reference Range | Status             | Verification Audit     |  |
|  +------------+---------------+-----------------+--------------------+------------------------+  |
|  | RBC        | 3.8           | 4.1 - 5.1       | [!] Low            | No prior edits         |  |
|  | Hemoglobin | 11.2          | 12.0 - 15.5     | [!] Low            | Edited: 11.0 -> 11.2   |  |
|  | Platelets  | 92            | 150 - 450       | [!!] CRITICAL LOW  | No prior edits         |  |
|  +------------+---------------+-----------------+--------------------+------------------------+  |
|  Role Verification check: You are logged in as Gamusi (Admin).                                  |
|  [Re-Open for Edits]                                                  [Approve and Sign Report]  |
+--------------------------------------------------------------------------------------------------+
```

#### 4.2 Separation of Duties & Rights Management
*   **Verification Permissions (RBAC)**: In the User Administration Settings, the **Absolute Owner (Admin)** assigns a boolean flag `has_verification_rights` to user accounts [user query]. Only users with this permission can access Screen 3 or execute the `/api/orders/{id}/verify` endpoint. Normal technician accounts are locked out of this tab [532].
*   **Audit Diff Insight**: To prevent unauthorized or blind "rubber-stamping" of reports, the Verification Panel dynamically renders the audit log history for that specific test run [3, 421]. If a result was edited after initial entry, it displays a yellow warning box detailing the modification (e.g., *"Tech1 changed Hemoglobin from 11.0 to 11.2 at 08:06"*), ensuring the verifier is aware of any transcript corrections.

#### 4.3 Interactive "One-Click Release"
*   **Click-to-Sign Workflow**: Once the verifier is satisfied with the results, they click **[Approve and Sign Report]** [258].
*   **The Technical Handshake**: This action sends a POST request to the backend. The server writes the verifier’s unique user ID and the current server timestamp into the `verified_by_user_id` and `verified_at` columns of the corresponding row in the `test_results` table [528].
*   **Unlocking the PDF**: Only when these columns are non-null does the ReportLab PDF rendering engine allow the report to be generated. If a user attempts to generate a PDF for an unverified test, the system locks the PDF button and displays a "Pending Verification" lock icon.

---

### 5. Screen 4: Test Menu Configuration (CRUD Catalog)

To ensure the system never hardcodes diagnostic tests and can adapt as AMH phases out obsolete assays (such as *Widal agglutination*) and introduces new panels, administrators have access to a full **Test Configuration Panel** [user query].

#### 5.1 UI Layout & Wireframe Blueprint
```
+--------------------------------------------------------------------------------------------------+
|  TEST MENU CONFIGURATION (ADMIN ONLY)                                    [ + Add New Test ]      |
|  +----------------------------------------------------------+  +-------------------------------+  |
|  | Filter Section: [ All Sections                      v]   |  | ADD/EDIT CONFIGURATION        |  |
|  +----------------------------------------------------------+  | Test Name: [Widal Agglut.   ] |  |
|  | Test Name    | Lab Section    | Incidence Tracker |Status |  | Section:   [ Parasitology  v] |  |
|  +--------------+----------------+-------------------+-------+  | [x] Track Positives (Epidem)  |  |
|  | CBC          | Hematology     | No                |Active |  | [ ] Active (Show in menus)    |  |
|  | Malaria MRDT | Parasitology   | Yes (Malaria)     |Active |  |                               |  |
|  | Widal Agglut | Parasitology   | No                |Active |  | Parameters:                   |  |
|  +--------------+----------------+-------------------+-------+  | [ Hb       ] [ g/dL ] [Add]   |  |
|  | Actions: [ Edit ] [ Soft-Delete / Disable ]               |  | [Cancel]          [Save Test] |  |
|  +----------------------------------------------------------+  +-------------------------------+  |
+--------------------------------------------------------------------------------------------------+
```

#### 5.2 Dynamic Test Menu and Section Management
*   **Laboratory Department/Section Configuration**: Admins can define high-level laboratory sections (e.g., Parasitology, Hematology, Clinical Chemistry, Microbiology) [528]. Tests are bound strictly to a section [528].
*   **Full CRUD (Create, Read, Update, Delete) Framework**:
    *   **Create**: Allows defining a test name, assigning its department, and creating multiple testing parameters (e.g., a "Lipid Profile" test can contain parameters: Total Cholesterol, HDL, LDL, Triglycerides) [528].
    *   **Update**: Allows editing test names or re-ordering parameter layouts.
    *   **Delete**: Soft-delete is enforced [srs part 3 queries, srs part 4 queries]. If a test is disabled/deleted (e.g., phasing out the *Widal Agglutination* test), it is marked as `is_active = 0` in the database [528]. It immediately disappears from Screen 2's ordering list to prevent technicians from adding it, but remains permanently in the database so historical client records and past reports can still be retrieved and printed without breaking data relationships.

#### 5.3 Incidence & Epidemic Tracking Flags
To support public health reporting requirements, the administrator can mark a test as an **Incidence Tracker** [user query, 24].
*   **Positive-Flagging Setup**: When creating or editing a test, checking the **"Track Positives"** box enables strict monitoring for that assay [user query]. It requires linking the positive outcome to a specific national reportable category (e.g., *Malaria microscopy positive*, *MRDT positive*, *HIV positive*, *Syphilis (VDRL/RPR) reactive*) [user query].
*   **Epidemic Action Integration**: When a technician logs a positive result for an incidence-tracked test in Screen 2, the LIMS-side autoverification engine automatically flags it [user query]. It appends it directly to the Monthly Epidemic Report, making reporting to the Ugandan Ministry of Health instantaneous and accurate.

---

### 6. Screen 5: Reports, Epidemic Tracking & Export

This screen generates administrative reports and compiles public health summaries [421, 543].

#### 6.1 UI Layout & Wireframe Blueprint
```
+--------------------------------------------------------------------------------------------------+
|  REPORTS & EPIDEMIC EXPORT PORTAL                                                                |
|  +--------------------------------------------------------------------------------------------+  |
|  | Date Range: [ 2026-07-01 ] to [ 2026-08-16 ]   | Department: [ Parasitology             v] |  |
|  | Filter Preset: [ Financial Year (July-June) v] | [Generate Report]                         |  |
|  +--------------------------------------------------------------------------------------------+  |
|                                                                                                  |
|  EPIDEMIOLOGICAL SUMMARY TABLE (UGANDAN MoH COMPLIANT)                                           |
|  +--------------------------------------------------------------------------------------------+  |
|  | Disease/Indicator Category          | Total Tested | Total Positive | Positivity Rate (%)  |  |
|  +-------------------------------------+--------------+----------------+----------------------+  |
|  | Malaria (Microscopy)                | 342          | 112            | 32.75%               |  |
|  | Malaria (RDT)                       | 520          | 204            | 39.23%               |  |
|  | HIV (Rapid Diagnostic Test)         | 150          | 6              | 4.00%                |  |
|  | Syphilis (VDRL/RPR)                 | 88           | 3              | 3.41%                |  |
|  +-------------------------------------+--------------+----------------+----------------------+  |
|  [Export MoH CSV (Uganda HMIS)]                                [Export Selecatable Vector PDF]   |
+--------------------------------------------------------------------------------------------------+
```

#### 6.2 Pre-defined Date Range Options & Presets
*   **Flexible Reporting Windows**: Supports filtering of datasets by specific custom start and end dates [421].
*   **Standard Presets**: Includes fast, single-click presets to match both hospital and Ministry of Health administrative schedules [421, 543]:
    *   *Daily*: Filtering for the current date.
    *   *Monthly*: Standard calendar months (e.g., August 1st - August 31st).
    *   *Ugandan Financial Year*: Automatically calculates and applies the standard Ugandan financial window from **July 1st to June 30th** of the following year [421].

#### 6.3 PDF Export & Preview Layout Spec
The vector-based ReportLab PDF engine generates professional, printable, and text-selectable clinical reports [user query]:
*   **Text-Selectable Vectors**: All text on the PDF remains fully selectable (not rasterized as an image), allowing hospital staff to easily copy data for copy-paste sharing [user query].
*   **Structural Report Sections**:
    1.  **Institutional Header**: Clean letterhead centering "Ahmadiyya Muslim Hospital Uganda - Laboratory Services" along with the physical address (Mbale) and contact channels [365].
    2.  **Client Demographics Panel**: Formatted as a side-by-side balanced table block containing Client ID, Full Name, Sex, Age/Date of Birth, Phone, and the Date of Collection [200, 201].
    3.  **Test Results Table**: Clean grid listing Parameter, Value, Unit, Reference Range, and Alert status [266].
    4.  **Verification Block**: Footer displaying the full name and digital ID of the verifying supervisor, the date of release, and a secure validation hash [266].

---

### 7. Ugandan Laboratory Default Reference Ranges & SOPs

To comply with Ugandan Ministry of Health (MoH) guidelines and international quality standards (**ISO 15189**), the system comes preloaded with standard diagnostic reference ranges [user query]. 

These defaults are dynamically evaluated based on the **Client’s Sex (Male/Female)** and **Age (Pediatric: 0-12 years vs. Adult: >12 years)** [201]. These serve as editable baselines that laboratory administrators can modify at will in Screen 4 to accommodate updated clinical SOPs [user query].

| Test Department | Test Name | Parameter Name | Sex Spec | Age Spec | Default Reference Interval | Default Critical Threshold (Trigger Alert) | Ugandan Lab SOP Precaution / Standard |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Hematology** | Complete Blood Count (CBC) | **Hemoglobin (Hb)** | Female | Adult (>12y) | 12.0 – 15.5 g/dL | < 7.0 g/dL or > 20.0 g/dL | Standard anemia monitoring. Critical values require immediate clinician notification [273]. |
| **Hematology** | Complete Blood Count (CBC) | **Hemoglobin (Hb)** | Male | Adult (>12y) | 13.5 – 17.5 g/dL | < 7.0 g/dL or > 20.0 g/dL | Evaluated under `DEVICE_PRESET` or `LIMS_EVALUATED` modes [user query]. |
| **Hematology** | Complete Blood Count (CBC) | **Hemoglobin (Hb)** | Co-sex | Pediatric (0-12y) | 11.0 – 14.5 g/dL | < 6.5 g/dL or > 19.0 g/dL | Pediatric critical thresholds are lower to match clinical risk profiles. |
| **Hematology** | Complete Blood Count (CBC) | **Platelets (PLT)** | Co-sex | Co-age | 150 – 450 × 10³/µL | < 50 or > 1000 × 10³/µL | Thrombocytopenia tracking. Low counts increase hemorrhagic risk. |
| **Biochemistry** | Renal Function Test (RFT) | **Serum Creatinine** | Female | Adult (>12y) | 44 – 97 µmol/L | > 300 µmol/L | Renal insufficiency monitor. Uses Ugandan preferred SI unit (µmol/L) [user query]. |
| **Biochemistry** | Renal Function Test (RFT) | **Serum Creatinine** | Male | Adult (>12y) | 53 – 106 µmol/L | > 350 µmol/L | Male muscle mass correlates to higher baseline reference intervals. |
| **Biochemistry** | Kidney / RFT | **Potassium (K+)** | Co-sex | Co-age | 3.5 – 5.1 mmol/L | < 2.5 or > 6.2 mmol/L | Severe cardiac arrhythmia risk if critical levels are breached [273]. |
| **Biochemistry** | Liver Function Test (LFT) | **Alanine Aminotransferase (ALT)** | Female | Co-age | < 33 U/L | > 200 U/L | Liver injury index. Measured in standard international catalytic units (U/L). |
| **Biochemistry** | Liver Function Test (LFT) | **Alanine Aminotransferase (ALT)** | Male | Co-age | < 41 U/L | > 250 U/L | ALT levels can vary with physical activity and metabolic profile. |
| **Biochemistry** | Diabetes Screening | **Random Blood Sugar (RBS)** | Co-sex | Co-age | 3.9 – 7.8 mmol/L | < 2.8 or > 15.0 mmol/L | Hypoglycemia (<2.8 mmol/L) represents immediate neuroglycopenic risk [273]. |

---

### 8. System Quality Checklist for FSD Part 5

To ensure Screen-by-Screen layouts strictly meet our functional, technical, and regulatory goals before implementation, the design must satisfy the following checklist:
*   [ ] **Zero manual typing for date formats**: Standardized `<input type="date">` used everywhere to prevent manual string transcription [538].
*   [ ] **100% selectability on generated PDFs**: Verified that no rasterization occurs during ReportLab canvas rendering [user query].
*   [ ] **Double-key validation for numerical entries**: Critical alert parameters (like Hemoglobin and Creatinine) trigger an immediate out-of-range visual warning to prevent typos.
*   [ ] **Complete encapsulation of soft deletes**: Deleted tests are excluded from the default directory but are accessible to system administrators via audit screens [346, user query].
