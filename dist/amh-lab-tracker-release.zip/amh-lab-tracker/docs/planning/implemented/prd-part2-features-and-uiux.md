# Product Requirements Document (PRD) — Part 2
## Core Feature Requirements & UI/UX Principles
**Ahmadiyya Muslim Hospital (AMH) — Mbale, Uganda**

---

### 1. Functional Requirements & Epics

The **AMH Lab Tracker** is divided into five core functional epics. Each feature is designed to support a strictly digital, offline, and secure laboratory environment.

#### Epic 1: Multi-User Profile Governance & Self-Registration
To ensure compliance with clinical standards (such as **ISO 15189** requiring personnel identification on all records [56, 170, 266]), the system enforces strict individual accountability:
* **Self-Registration:** Technicians can register their own unique accounts directly from the shared laboratory computer [535]. Registration requires their full name, a unique username, and a password [528].
* **Individual Attribution:** When a user is logged in, their full name is dynamically mapped to every test order they log, result they enter, and official report they print [56, 170, 266, user query]. Reports must bear the actual performing technician's name rather than a generic role [user query].
* **Role-Based Access Control (RBAC):** 
  * *Technicians:* Can register clients, log tests, enter results, view trends, and print reports [528]. They are strictly prohibited from deleting records or altering test configurations [528, 533].
  * *Administrators:* Possess full administrative access, including the ability to manage user accounts, modify or disable tests, and view the immutable system audit log [528, 533].
* **Auto-Session Timeout:** To prevent unauthorized crossover logging on shared terminals, the backend enforces an aggressive 15-minute session inactivity expiration, and the frontend automatically locks the screen and logs the user out if no mouse or keyboard activity is detected for 15 minutes [536].

#### Epic 2: Dynamic Test Menu Configuration
The lab menu is highly dynamic and must expand or contract with the hospital's clinical offerings [user query]:
* **Custom Test Definition:** Administrators must be able to freely create new tests, define normal/reference ranges, specify units of measure, and group them by laboratory section (e.g., Microbiology, Hematology, Biochemistry) [528, user query].
* **Test Phasing Out (Deletion/Deactivation):** The system must allow administrators to freely delete or deactivate obsolete tests (for example, phasing out *Widal agglutination* testing) [user query].
  * *Constraint:* If a test has historical daily logs or patient results attached to it, the system must perform a soft-delete (marking it as inactive in the `tests` table) to preserve historical data integrity while removing it from the active test menu [528].

#### Epic 3: Complete Paperless Operations & Printing Integration
The AMH Lab Tracker replaces the physical paper register entirely [user query]:
* **100% Database Capture:** Technicians are required to register every client and test run in the application [user query]. The database acts as the single source of truth, making manual paper registries obsolete [user query].
* **Result Printing Workflow:** The system generates clean, formatted results in a standardized letterhead layout [421]. The web frontend dynamically triggers the system print dialog using the native browser or shell print API to print these results [423, user query]. Because printing requires a digital record, no results can be issued without being recorded in the database, ensuring perfect record capture [user query].

#### Epic 4: Clinical Critical Value Alerts
To comply with international laboratory standards (such as **ISO 15189 Clause 7.3** and **CLSI AUTO10** regarding alert values [13, 273]), the system features a built-in clinical warning engine:
* **Flagging Out-of-Bounds Values:** When numeric results are entered for standard clinical profiles, the system automatically checks them against Ugandan national clinical standards and standard operating procedures (SOPs) [user query].
* **Target Diagnostic Panels:** Specifically, critical alerts must be programmed for:
  * *Complete Blood Count (CBC):* Flagging critical hemoglobin, platelet, or white blood cell counts [user query].
  * *Liver Function Tests (LFTs):* Flagging severely elevated bilirubin, ALT, or AST [user query].
  * *Renal Function Tests (RFTs):* Flagging critical urea or creatinine levels [user query].
  * *Blood Sugar / Glucose:* Flagging extreme hypoglycemia or hyperglycemia [user query].
* **Non-Disruptive UI Design:** Alerts must flag critical values clearly using high-visibility, high-contrast visual indicators (e.g., red highlight, 'CRITICAL' flag icon, and bold text) directly on the results screen [user query]. It must **not** use dramatic or disruptive modal popups that block the technician's typing flow during fast data entry [user query].

#### Epic 5: Immutable System Audit Logging
To meet international regulatory requirements (such as **21 CFR Part 11** [3, 8]), the application runs an automated background audit logging system:
* **Background Recording:** Every database modification (registering a client, updating a test result, deactivating a test, or creating a user) is caught automatically [505].
* **Audit Metadata:** Each audit entry captures the precise date and time, the unique user ID/full name of the operator, the specific action taken, and the exact old and new values of the modified fields [421, 528].
* **Immutability:** The audit log table is completely read-only, stored in a separate relational sequence that cannot be modified, edited, or cleared by any user, including administrators [3, 8].

---

### 2. UI/UX & Interface Specifications

#### Low-Resource Visual Style
* **Flat Layout:** The interface utilizes a lightweight, clean, and completely flat layout with zero resource-heavy animations, shadows, or rounded gradients [user query, 524]. This ensures the application consumes almost no GPU/RAM, preventing freezes on 15-year-old Core 2 Duo systems [user query, 524].
* **High-Contrast Colors:** A high-contrast medical color scheme (e.g., standard medical green, clinical navy, and white) to ensure readable text on old, low-brightness cathode-ray or early LCD monitors [user query].
* **System Theme Preservation:** The application UI reads the browser or operating system's default light/dark preference presets (e.g., via standard media queries) and scales its styling accordingly to ensure visual comfort [user query]. No heavy dark-mode toggle switch or customized theme engine is rendered on-screen to save memory [user query].

#### Interaction & Usability Guidelines
* **Dual-Mode Data Entry:** The user interface is fully optimized for both real-time individual test entries at the bench and high-speed batch transcription of logs at the end of a shift [173, user query].
* **Keyboard-Only Operation:** For batch logging, technicians can navigate through forms, search lists, and result grids purely using the keyboard (e.g., `Tab` to move to the next field, `Shift+Tab` to move back, and `Enter` or `Ctrl+S` to save) [173]. Technicians do not need to use a mouse [173].
* **Destructive Action Guards:** Any destructive admin action (such as deleting a user account or deactivating an active laboratory test) must trigger a clear confirmation prompt before execution, preventing accidental data loss.
