# Functional Specification Document (FSD) — Part 6
## AMH Lab Tracker — Desktop Laboratory System
**Ahmadiyya Muslim Hospital (AMH) — Mbale, Uganda**
**Document Version: 2.0 (Direct Client Feedback Integration)**

---

### 1. Sequential Lab Numbers & Monthly Registration Lifecycle

To prevent duplicate client registrations and establish an absolute canonical key for all laboratory workflows, the **AMH Lab Tracker** utilizes a highly structured, sequential **Lab Number** format instead of random database identifiers or complex manual indexing [user query].

#### 1.1 Lab Number Architecture & Syntax
The Lab Number serves as the primary identifier for every client order, sample container, and diagnostic printout [user query]. It is generated automatically by the backend database using the following format:
`[FACILITY]-[YY]-[MM]-[SEQUENTIAL_NUMBER]`

*   **`FACILITY`**: Hardcoded to `AMH` (Ahmadiyya Muslim Hospital) [user query].
*   **`YY`**: Two-digit calendar year (e.g., `26` for 2026).
*   **`MM`**: One- or two-digit calendar month (e.g., `8` for August, `9` for September) [user query].
*   **`SEQUENTIAL_NUMBER`**: A three-digit, zero-padded integer starting at `001` [user query].

#### 1.2 Monthly Automatic Reset Protocol
The system enforces a strict monthly rollover mechanism in the database layer. At exactly `00:00:00` on the first day of each calendar month, the sequence automatically resets [user query].
*   *August 2026 Run:* `AMH-26-8-001`, `AMH-26-8-002` ... `AMH-26-8-500` [user query].
*   *September 2026 Run:* `AMH-26-9-001`, `AMH-26-9-002` ... [user query].

**Database Level Implementation (Trigger Logic):**
```sql
-- Trigger to enforce sequential incrementing and monthly reset
CREATE TRIGGER IF NOT EXISTS generate_sequential_lab_number
AFTER INSERT ON test_orders
FOR EACH ROW
WHEN NEW.lab_number IS NULL
BEGIN
    UPDATE test_orders
    SET lab_number = (
        SELECT 'AMH-' || strftime('%f', NEW.ordered_at) || '-' || strftime('%m', NEW.ordered_at) || '-' ||
               LPAD(COALESCE(
                   (SELECT CAST(SUBSTR(lab_number, instr(lab_number, '-', 1, 3) + 1) AS INTEGER)
                    FROM test_orders
                    WHERE strftime('%Y-%m', ordered_at) = strftime('%Y-%m', NEW.ordered_at)
                      AND id != NEW.id
                    ORDER BY id DESC LIMIT 1), 0) + 1, 3, '0')
    )
    WHERE id = NEW.id;
END;
```

#### 1.3 Intraday Same-Day Lab Number Reuse
To ensure a paperless, un-duplicated operation, if a client receives multiple separate tests on the same calendar day, the system **must reuse the same Lab Number** [user query]. The Lab Number covers all diagnostic parameters logged for that client during that specific visit, allowing consolidated reporting [user query].

#### 1.4 Smart Client Autocomplete & Suggestion Engine
While long-term longitudinal client tracking is not the primary diagnostic focus (which remains focused on test output logging) [user query], the system must prevent technicians from typing redundant details for returning clients [user query].
1.  **Search-as-you-type Trigger:** As the technician types a name into the "Client Name" field on Screen 2 (Registration & Intake), the frontend issues an asynchronous, debounced (150ms) GET request to `/api/clients/suggest?name=...` [529].
2.  **Database suggestion return:** The backend queries the `clients` table using a fast indexed query:
    `SELECT full_name, date_of_birth, sex, phone FROM clients WHERE full_name LIKE ? LIMIT 5;`
3.  **Client-Side Auto-Population:**
    *   If a match is found, it is displayed in a lightweight dropdown list directly under the text field.
    *   Clicking a suggestion immediately copies the client's existing **Full Name, Date of Birth/Age, Sex, and Phone Number** into the intake form [user query].
    *   **The Crucial Step:** Selecting a historical client does *not* reuse their historical Lab Number. Instead, the backend immediately generates a **brand-new sequential Lab Number for the current month/day run** to ensure the daily tracking ledger remains perfectly aligned [user query].

---

### 2. High-Throughput Keyboard Data Entry Workflows

To support rapid, end-of-shift transcription from paper worksheets and fast real-time bench entries during diagnostic spikes, the **AMH Lab Tracker** provides a highly responsive, mouse-free input workflow [518, user query].

#### 2.1 Vertical Cursor Progression (Tab Sequence)
1.  **Vertical Tab Navigation:** Inside the active tests workbench (Screen 2), pressing the `Tab` or `Enter` key automatically moves the browser focus **vertically down** to the next numerical result input field (e.g., from RBC -> Hb -> WBC -> Platelets) rather than jumping horizontally across action buttons [519].
2.  **Reverse Progression:** Pressing `Shift + Tab` moves the focus vertically upward.
3.  **Dynamic Focus Retention:** When the cursor reaches the final parameter input row, pressing `Tab` or `Enter` moves the focus directly to the **`[Submit Results]`** action button. Pressing `Enter` on this button submits the entire form, clears the workbench, and returns focus to the "Client Name" input field to begin the next registration instantly.

#### 2.2 Typos and Data Sanitization Filters
To prevent transcription errors (such as entering letters or decimal misalignment) from contaminating the database, the client-side inputs execute strict filtering:
*   **Characters Allowed:** Standard number keypads, period (`.`), and backspace/delete.
*   **Alphabetical Key Block:** If a technician accidentally hits an alphabetical key (e.g., typing "12.O" instead of "12.0"), the keypress is discarded immediately by an `onkeypress` event listener, and a subtle **red border glow** flashes around the active input box to provide immediate tactile feedback without throwing annoying pop-up boxes [538].
*   **Value Normalization:** If a value with leading zeros (e.g., "09.4") or stray trailing periods ("12.") is entered, the JavaScript normalizes the string to a valid float ("9.4" and "12.0") before packaging the JSON POST request to the backend.

---

### 3. Non-Blocking Clinical Alerts & Flagging Standards

In strict compliance with modern clinical standards (including **ISO 15189 Clause 7.3** and **CLSI AUTO10** regarding diagnostic limits), the system implements an automated flagging layer [12, 13, user query].

#### 3.1 Non-Blocking Flagging Philosophy
The application does not subject technicians to disruptive alert banners, modals, or interface blocks that force manual clicks to close [user query]. Instead:
1.  **On-Screen Indicators:** As values are entered or imported via the clipboard portal, the backend calculates and displays clean, color-coded indicators inside the test parameters table [user query]:
    *   `[!] High` (Orange text): Entered value exceeds upper reference limits [user query].
    *   `[!] Low` (Blue text): Entered value falls below lower reference limits [user query].
    *   `[!!] Critical` (Bold red text with a warning icon): Entered value falls into extreme ranges that represent imminently life-threatening limits [273, user query].
2.  **Clinician Interpretation Notes:** Reference ranges and clinical explanations are outputted directly in the **ReportLab PDF report headers and footers** [user query, 261]. The printed reports carry these flags clearly alongside the results [user query]. The laboratory's operating standard relies on the clinical officers to read the printed results, understand the flags, and handle patient care accordingly [user query].

---

### 4. Role-Based Editing and Correction Workflows

To prevent over-engineering while maintaining proper administrative control over clinical data, the system relies on role-based configuration flags instead of complex immutable record locking [user query].

#### 4.1 Granular Editing Rights (The "Trusted" Technician Model)
The system establishes a specific boolean flag inside user profiles: **`can_edit_results`** [user query].
*   **Technicians without Editing Rights:**
    *   Can perform initial registration, order tests, enter numerical results, and submit them.
    *   Once submitted, the input fields are rendered as read-only.
    *   If they attempt to modify an entry, the UI displays a lock symbol. They must contact a senior technician or administrator to execute corrections [user query].
*   **Trusted Technicians with Editing Rights:**
    *   Are recognized by the system as "tried, tested, and trusted" senior professionals [user query].
    *   They can freely click an **`[Edit Results]`** button on any logged record to unlock the fields and correct typos or errors in real-time [user query].
    *   The workflow remains completely unblocked, allowing seamless, rapid adjustments during fast-paced shifts.

#### 4.2 Append-Only Database Audit Logging of Corrections
Every single modification executed by a trusted technician is captured automatically by the backend database triggers and logged in the immutable `audit_log` table [421, 528]:
*   The log captures: **User ID of the editor, timestamp, parameter changed, old value, and new value** [528].
*   This ensures that while the workflow remains flexible and agile in the lab, a full history is preserved for quality assurance audits [3, 421].

---

### 5. Automated Scheduled Backups & Database Restoration

To safeguard AMH's clinical database from hardware failures, power cuts, or file corruption without relying on "childish" manual USB copy buttons, the system runs an automated background backup thread [user query, 516].

#### 5.1 Initial Setup Backup Folder Selection
During the initial application setup (and adjustable at any time inside the Configuration / User Settings screen), the administrator selects a **local backup directory/folder** [user query].
*   This folder can be any path accessible to the operating system (such as a separate physical partition, an external backup drive, or a local directory synchronized to a network drive) [user query].
*   The backup destination path is stored securely in the local `app_config` database table.

#### 5.2 6-Hour Automated Background Backup Daemon
The FastAPI backend server initializes a persistent, lightweight background scheduler daemon upon boot:
1.  **Interval:** Every **6 hours** of continuous server runtime, the background task executes [user query].
2.  **Safety Lock check:** The thread performs a database integrity check using `PRAGMA integrity_check;` to verify that the active database is healthy and uncorrupted before initiating a backup.
3.  **Hot Backup Execution:** If the database is healthy, the thread copies `amh_lab.db` using Python’s native, thread-safe `shutil.copy2` to the configured backup location.
4.  **Unique Timestamping:** Backups are saved with a clean, unique timestamp:
    `amh_backup_YYYY-MM-DD_HHMMSS.db`
5.  **Retention Policy:** The system maintains a rolling 30-day backup sequence, automatically deleting files older than 30 days to prevent disk space exhaustion.

#### 5.3 Automated Database Restoration (Disaster Recovery)
If a primary database file is corrupted due to an abrupt power outage, administrators can restore the system directly from the UI:
1.  **Restore Portal:** Under Admin Settings, the administrator clicks **`[Restore Database]`**.
2.  **File Selection & Validation:** The browser opens a local file selection dialog. The admin selects a backed-up `.db` file [user query].
3.  **Verification Check:** Before writing the selected database as active, the Python backend executes a test mount and verifies the tables (checking for the exact schemas, foreign keys, and triggers defined in Part 3) [srs part 3 queries].
4.  **Safe Rollback Overwrite:** If validation passes, the active server process halts database connections, renames the corrupted file to `amh_lab_corrupted.db.old`, copies the selected backup to `amh_lab.db`, and re-establishes the WAL database pool. If validation fails, the active database is preserved, and the user is shown a clear "Invalid Database Schema" error.

---

### 6. Technical Workflows & Edge-Case Verification Matrices

| User Action / Edge Case | Expected System Behavior | Technical Verification Mechanism |
| :--- | :--- | :--- |
| **New client with same name as existing profile** | Autocomplete dropdown renders historical matching clients [user query]. Technician selects match. Form populates details [user query]. System creates order under a **new sequential Lab ID** for current month [user query]. | GET `/api/clients/suggest?name=...` queries index. POST `/api/orders` inserts new row with generated sequence based on current server date [528, 529]. |
| **Technician attempts to edit a finalized result** | System checks logged-in user role permissions. If user lacks `can_edit_results`, edit is blocked in UI. If user has permissions, edits are unlocked instantly [user query]. | Middleware evaluates user object returned from `get_current_user` dependency [533, 535]. UI toggles input `readonly` properties dynamically. |
| **Out-of-range clinical results entered** | High, Low, or Critical diagnostic flags render next to numerical input fields instantly [user query]. Report prints with flags and clinical reference notes [user query, 261]. | Javascript runs local evaluations against default reference ranges. HTML report template appends `H`/`L`/`C` markers to values. |
| **Active database locks during high-throughput entry** | Technicians continue entering results in multiple browser tabs concurrently with zero freezes [ srs part 3 queries, srs part 4 queries]. | SQLite database operates under **Write-Ahead Logging (WAL)** mode with connection timeouts set to 30.0s [srs part 3 queries, srs part 4 queries]. |
| **Monthly sequence rollover (August to September)** | The sequential lab number resets to `001` at midnight on September 1st [user query]. | SQL Insert trigger evaluates current calendar month and calculates sequence based on partition of `YYYY-MM` [528]. |
