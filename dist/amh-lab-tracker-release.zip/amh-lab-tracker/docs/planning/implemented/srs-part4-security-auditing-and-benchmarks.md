# Software Requirements Specification (SRS) — Part 4
## Security Protocols, Auditing & Performance Benchmarks
**AMH Lab Tracker — Ahmadiyya Muslim Hospital (AMH), Mbale, Uganda**

---

### 1. User Governance & Access Control

To maintain regulatory alignment under international standards (such as **ISO 15189:2022** and **FDA 21 CFR Part 11**), the AMH Lab Tracker implements strict administrative, physical, and technical controls, even when operating in an offline, local-only environment [3, 443]. 

#### 1.1 Data Ownership & Role-Based Access Control (RBAC)
The core architectural principle of the AMH Lab Tracker is that **no user owns the diagnostic or client data they input**. Data ownership belongs solely to Ahmadiyya Muslim Hospital. The system restricts modifications to configurations and records based on role templates [171, 494]:

*   **Admin Profile (The Absolute Owner):** 
    *   Holds exclusive global administrative privileges.
    *   Authorized to perform password overrides, reset security questions, add or delete test items in the global catalog, and inspect the immutable audit logs [421, 494].
    *   Holds exclusive authority over destructive actions (soft deletes) and master configurations [494].
*   **Technician Profile:**
    *   Authorized to register client profiles, log orders, input test values, and run clipboard integrations [85, 421].
    *   Granted read-and-write permissions for daily clinical workflows but blocked from altering global settings, performing permanent data deletions, or resetting other users' credentials [3, 421, 494].

#### 1.2 Unified Security Recovery Handshake
To eliminate deployment and operational bottlenecks in an air-gapped system, password recovery is engineered using a localized, secure self-service and administrative override protocol:

1.  **Single Secure Security Question:** During account registration, the technician selects and answers a single, highly secure, custom-defined security question (e.g., *"What is your primary school registration number?"*). The answer is salted and cryptographically hashed in the database [171].
2.  **Self-Service Recovery:** If a technician forgets their password, they can trigger a recovery screen, answer their security question, and input a new password [171].
3.  **Administrative Override:** If the user forgets both their password and the answer to their security question, the **Admin Profile** can execute a manual override to reset the account's password to a temporary placeholder (`<CHANGE_ON_FIRST_LOGIN>`) and clear the security question [421, 491]. No user, including the Admin, can view past passwords as they are permanently scrambled [171].
4.  **Clinical Data Integrity Safeguard:** Under no circumstances shall password resets, account locking, or credentials recovery interfere with or touch existing test data, patient history, or clinical records [491].

---

### 2. Physical & Technical Session Security

Because lab workstations at AMH are shared physically by multiple technicians who rotate between the testing benches and computer terminals [516, 536], session security must prevent "walk-away" vulnerabilities where one technician accidentally logs or signs results under another technician's active credentials [171, 536].

#### 2.1 The 15-Minute Inactivity Session Timeout
*   **Frontend Activity Daemon:** The client application (app.js) operates a background activity listener tracking mouse movement, keyboard strokes, and touch inputs. 
*   **Auto-Lock Execution:** If no user interaction is detected for exactly **15 minutes**, the frontend daemon immediately clears the local memory cache (including the active user object), invalidates the frontend state, and redirects the interface to the Login Modal, displaying an alert: *"Session expired due to inactivity."* [536]
*   **Backend Token Expiration:** All user sessions are backed by short-lived, random 64-character tokens stored in the `user_sessions` table [532]. The backend database-level `expires_at` timestamp is calculated dynamically upon every API request to be exactly `CURRENT_TIMESTAMP + 15 minutes`. If an incoming session cookie exceeds this threshold, the API immediately throws an `HTTP 401 Unauthorized` exception [532, 536].

#### 2.2 Physical Workstation Hardening
*   **Automatic Screen Lockouts:** Workstation operating systems must be configured with a matching 15-minute screen saver lockout to prevent unauthenticated physical access to the local desktop environment [493, 495].
*   **Unused Port Disabling:** To safeguard the air-gapped host computer from malicious local physical vectors (such as USB rubber duckies or malware-infected storage keys), unused external USB ports and boot options must be locked down via the BIOS password [493].

---

### 3. Flexible Reference Range & Clinical Flagging Engine

A critical requirement of the AMH Lab Tracker is its dual-mode clinical flagging engine, which accommodates both vendor-calibrated hardware and manual test parameters.

```
                  +-----------------------------------+
                  |      Incoming Test Result         |
                  +-----------------------------------+
                                    |
                                    v
                  +-----------------------------------+
                  | Is Parameter Calibrated Externally|
                  |     (e.g., Biotech Analyzer)?     |
                  +-----------------------------------+
                               /         \
                             YES          NO
                             /             \
                            v               v
             +-----------------------+     +-------------------------------+
             |     DEVICE_PRESET     |     |        LIMS_EVALUATED         |
             |  Accept Value & Flags |     |  Calculate High/Low/Critical  |
             |       Exactly As-Is   |     |    Flags via Age & Sex Schema |
             +-----------------------+     +-------------------------------+
```

#### 3.1 Device-Preset Mode (`DEVICE_PRESET`)
*   **Context:** High-throughput diagnostic equipment, specifically the **Nihon Kohden Hematology Analyzer**, is calibrated periodically by specialized external vendors (e.g., **Biotech**). These analyzers contain internal pre-set reference ranges, alert thresholds, and flags printed directly on their diagnostic readouts.
*   **Protocol:** For parameters flagged as `DEVICE_PRESET`, the AMH Lab Tracker **must bypass LIMS-side validation rules**. The system records the clinical values exactly as transmitted or pasted from the analyzer (e.g., WBC, RBC, Platelets, Hemoglobin) and preserves the analyzer's built-in alerts (H, L, Critical) without applying database-calculated thresholds. This prevents invalidating the manufacturer's certified calibration.

#### 3.2 LIMS-Evaluated Mode (`LIMS_EVALUATED`)
*   **Context:** Routine manual assays, rapid tests, or chemistry analyzers purchased in the future without built-in reference configurations.
*   **Protocol:** For parameters configured as `LIMS_EVALUATED`, the LIMS dynamically evaluates clinical ranges using the schema defined in the `test_parameters` table:
    *   **Demographic Segmentation:** The reference checking code evaluates the patient's **Age** (calculated dynamically in days or years from their date of birth) and **Sex** (Male, Female, Pediatric, or General) [201].
    *   **Flag Generation:** Results are auto-analyzed upon save. If a value falls outside the defined range, it is dynamically stamped in the database with standard clinical codes:
        *   `H` (High) / `L` (Low)
        *   `CH` (Critical High) / `CL` (Critical Low)
    *   **Technical Flag Override:** Administrators retain the authority to configure override rules in the test parameters menu to switch any parameter's evaluation mode between `DEVICE_PRESET` and `LIMS_EVALUATED` as testing methods evolve.

---

### 4. Immutable Audit Logging (FDA 21 CFR Part 11 Standard)

The system enforces complete traceability for every data write, update, and configuration change via a secure, append-only auditing mechanism [3, 8].

#### 4.1 Log Schema & JSON Payload Diffing
To prevent simple, superficial logging that fails compliance scrutiny, the `audit_log` table stores high-granularity technical payloads [7]:
*   **User Attribution:** Captures the unique user ID, username, IP loopback address (`127.0.0.1`), and time stamp of every database modification [505].
*   **Immutable JSON Payloads:** Rather than recording simple text strings, all modifications and deletions capture the complete data diff in JSON format:
    *   `old_values`: A JSON dictionary representing the row's state immediately prior to the edit.
    *   `new_values`: A JSON dictionary representing the newly requested row state.
*   **Append-Only Enforceability:** The database connection factory isolates the `audit_log` table. The application backend contains no functions to edit or delete records from the `audit_log` table, establishing an unalterable paperless history [3, 8].

#### 4.2 Logging Scope
The system logs 100% of the following events:
1.  **Authentication Events:** Logins, logouts, failed login attempts (tracking username and reason), password resets, and user profile creations [504].
2.  **Clinical Operations:** Any insertion of new patient logs, creation of test orders, result entries, and clinical result verifications [505].
3.  **Administrative Actions:** Dynamic addition or deletion of test items in the catalog, modification of reference intervals, and database backup operations [505].

---

### 5. Soft Deletes & Statistics Integrity

In compliance with medical record retention rules (such as **ISO 15189** requiring a minimum 7-year document lifespan for general laboratory reports), no client files or diagnostic orders can be physically deleted from the SQLite database [170, 277].

#### 5.1 Soft Delete Implementation
*   **Flag Schema:** All primary tables (`clients`, `test_orders`, `test_results`) are compiled with an `is_deleted` (BOOLEAN) flag defaulting to `0` (Active).
*   **Destructive Action Masking:** When a technician or administrator "deletes" a record (e.g., due to a canceled test or typo), the backend executes an `UPDATE` query setting `is_deleted = 1`. The record remains physically intact within the SQLite database.

#### 5.2 Statistics & KPI Contamination Prevention
To eliminate the severe risk of data corruption, financial discrepancy, or public health misreporting (e.g., counting canceled or deleted malaria tests in the hospital's positivity rates), **every analytical and reporting query must strictly enforce logical isolation**:

*   **Query Filtering:** All SQL queries executing counts, sums, averages, or positivity rates on the backend must explicitly include the clause:
    ```sql
    WHERE is_deleted = 0
    ```
*   **Reporting Verification Tests (PQ):** Performance Qualification (PQ) test scripts must include "contamination checks" to verify that soft-deleted entries are completely excluded from daily registries, monthly reports, and trend graphs [346].

---

### 6. Security & Performance Benchmarks

#### 6.1 Performance Benchmarks
To ensure the AMH Lab Tracker operates smoothly on Mbale's legacy Core 2 Duo computers with 2GB RAM [516, 524], the following non-functional benchmarks are enforced:

| Operational Metric | Target Benchmark | Verification Method |
| :--- | :--- | :--- |
| **System RAM Footprint** | $\le$ 150 MB (Uvicorn + Python + PyWebView) | Task Manager monitoring under heavy write conditions |
| **Client Search Latency** | $\le$ 200 ms for database lookup (5,000 records) | Chrome DevTools network performance profiling |
| **Page-View Load Time** | $\le$ 100 ms (Instantaneous SPA Tab Switch) | Local lighthouse auditing and rendering timing |
| **PDF Generation Speed** | $\le$ 1.5 seconds for multi-page vector PDF | ReportLab performance logging during export |

#### 6.2 Security Benchmarks
*   **Password Hashing Complexity:** PBKDF2 with SHA-256 and a minimum of 100,000 iterations [533].
*   **Local Port Isolation:** Binds strictly to `127.0.0.1:8756`, rejecting any inbound LAN or Wi-Fi traffic [516, 524].
*   **Data-at-Rest Encryption:** AES-256 encryption applied to offline database backups exported to external USB storage devices [495, 497].
