# Product Requirements Document (PRD) — Part 1 (v2)
## AMH Lab Tracker — Desktop Laboratory System
**Ahmadiyya Muslim Hospital (AMH) — Mbale, Uganda**

---

### 1. Executive Summary & Product Vision
The **AMH Lab Tracker** is a proprietary, offline-first clinical laboratory database system engineered specifically for the operational environment of **Ahmadiyya Muslim Hospital in Mbale, Uganda** [421, 545]. 

The primary vision of the **AMH Lab Tracker** is to establish a secure, modern, and highly performant database-backed system that runs completely locally and offline [421, 516]. Designed to support 100% digital data capture, the system eliminates manual recording gaps by requiring all diagnostic tests to be logged in the application before results are printed [user query]. 

The system delivers three core pillars of modern laboratory operations:
1. **Uncompromising Data Integrity:** A robust relational SQLite database that replaces manual registries, ensuring all records are securely structured, search-indexed, and immune to accidental file deletions or database corruption [421, 516].
2. **Operational Accountability:** An automated background audit trail that logs every user login, client record creation, test configuration edit, and result update with precise time, date, and user stamps [3, 421, 505].
3. **Clinical Compliance & Standards:** Features built directly to support clinical laboratory standards of practice, such as role-based user access controls [3, 421, 494], automated verification, critical value alerts [13, 273], and individual technician attribution on all official printed report slips [56, 266, user query].

---

### 2. Operating Environment & Technical Constraints
To run effectively in Mbale, the AMH Lab Tracker is optimized for highly constrained infrastructure, strictly adhering to these operational boundaries:
* **Host Hardware Limitations:** The laboratory operates legacy workstation computers (typically Intel Core 2 Duo era processors with 2GB of RAM) [423, 516, 524]. The application must consume minimal system resources (prohibiting heavy modern shells like Electron) to prevent system freezes or slow-downs [516].
* **Network Isolation (Air-Gap):** The laboratory is completely offline, with no reliable internet connectivity [516]. The application must run **100% locally** on a single computer, with zero external dependencies, CDNs, or cloud-hosted services [516].
* **Offline Deployment Strategy:** All software installations, upgrades, and library dependencies must be delivered on physical USB flash drives containing pre-compiled, offline Python wheel (`.whl`) files and local installation scripts (`install.py`, `pack_usb.bat`) [390, 404, 421].
* **Local Loopback Security:** To ensure privacy and protect electronic health records from unauthorized external access over local Wi-Fi or LAN, the server must bind strictly to the local loopback interface (`127.0.0.1`) at port `8756` [516, 524].

---

### 3. User Personas & Workflows

#### Persona A: The Laboratory Technician (The Core Operator)
* **Profile:** Trained clinical laboratory professionals who perform diagnostic assays, record results, and generate printed reports for clients [82, 85]. Their computer literacy is basic to moderate [388, 516].
* **Operational Reality:** Techs work under highly dynamic diagnostic pressures, where client volume and test queues dictate their logging pace [user query]. They operate in two distinct workflows:
  * *Real-Time Entry:* Logging client demographics and test results immediately at the testing bench as assays are run (best for low to moderate queues) [user query].
  * *Batch Transcription:* Entering several records in rapid succession during peak hours or at the end of a high-volume shift [173, user query].
* **Critical Needs:**
  * **Dynamic Printing Integration:** Every test run must be captured in the database to enable the printing of official results [user query]. The UI must seamlessly trigger the system print dialog for generated report assets [423].
  * **Rapid Keyboard-Driven UI:** Tab and Enter-focused navigation keybinds to allow rapid batch data entry without taking hands off the keyboard [173].
  * **Strict Data Validation:** Clean calendar date pickers [538], constrained numeric fields, and dropdown test selections to prevent invalid, corrupt, or mistyped data entries [173].

#### Persona B: The Laboratory Administrator / Director
* **Profile:** Senior laboratory director or supervisor responsible for general operations, quality assurance, and compliance with national and international standards [48, 73, 88].
* **Operational Reality:** Monitors overall testing throughput, positivity rates, and system audit logs [421, 543]. They require accurate, aggregated reporting to assist in clinical decision-making and disease surveillance [24].
* **Critical Needs:**
  * **Full Traceability:** The ability to trace every printed report and database entry to the exact technician who performed the work, ensuring compliance with international laboratory standards (e.g., ISO 15189 [56, 266]).
  * **Audit Log Viewer:** A secure, read-only interface displaying an immutable ledger of all system edits, deletions, and administrative actions [3, 8].
  * **Flexible System Management:** A dedicated configuration panel where they can add, update, or disable tests and manage user accounts without touching the underlying source code [user query].

---

### 4. Success Metrics
The success of the AMH Lab Tracker deployment will be benchmarked against the following performance indicators:
1. **100% Digital Capture:** Zero unrecorded tests. Every single diagnostic test performed in the lab is captured electronically in the local SQLite database prior to printing [user query].
2. **Zero System Freezes:** The application maintains a memory footprint below 150MB, running smoothly on legacy 2GB RAM workstations without a single performance freeze [516, 543].
3. **Instantaneous Report Aggregation:** Compilation of monthly aggregates, positivity rates, and filtered diagnostic data in under 5 seconds [421, 543].
4. **Complete Regulatory Traceability:** 100% of database-altering actions are captured in the immutable background audit ledger, securely mapped to the specific logged-in user profile [3, 421, 505].
