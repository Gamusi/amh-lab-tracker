# Planned Features Roadmap

This document serves as a roadmap for future advanced features and enhancements for the AMH Lab Tracker (ALT).

## 1. Full Hardware Automation via RS-232 COM Ports & Graphical Curve Capture [WIP]

### Goal
To completely replace the legacy AMSS VB6 software and achieve 100% zero-click automation for laboratory testing data ingestion, including automated capture and rendering of cell volume distribution histograms (WBC, RBC, PLT curves).

### Technology Stack
- **Daemon / WebSerial:** A background Python service utilizing the `pyserial` library or in-browser WebSerial API adapter.
- **Hardware:** USB-to-Serial (RS-232) converter connecting the Nihon Kohden analyzer to the server/workstation.
- **Graphics Pipeline:** Binary frame decoding to extract raw multi-channel particle size distribution bins and render ReportLab vector histograms on PDF reports.

### Workflow
1. **Port Listening:** The Python daemon / WebSerial service listens to the configured COM port (e.g., `COM3`) on the workstation.
2. **Data Broadcast:** When the Nihon Kohden analyzer completes a test cycle, it broadcasts the test results, machine calibration reference limits (`EXP`), and optional extended graphic/histogram frames over the RS-232 serial interface.
3. **Data Capture & Parsing:** The stream reader intercepts the transmission in real-time. It extracts client sample identifiers, 22 numerical parameters, hardware flags (`*`, `H`, `L`), calibrated reference intervals, and binary histogram curves.
4. **API Integration:** Immediately following data extraction, a structured JSON payload is posted to the ALT backend via `/api/orders/analyzer-import` or `/api/integrations/parse-analyzer-output`.
5. **Real-Time UI & PDF Update:** The backend processes incoming data, attaches machine reference ranges to the visit order, pre-populates the technician review modal, and generates single-page dedicated CBC PDF reports with full histogram graphics.

