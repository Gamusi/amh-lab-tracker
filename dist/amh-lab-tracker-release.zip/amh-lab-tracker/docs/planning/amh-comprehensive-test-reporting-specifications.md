# AMH Comprehensive Laboratory Test Reporting Specifications

## Master Dictionary for LIMS Database Schemas, Report Generation, and HMIS 105 Compliance

**Ahmadiyya Muslim Hospital, Mbale, Uganda**  
*Document Ref: AMH-LIMS-COMP-REP-2026*  
*In Compliance with: Ministry of Health (MoH) Uganda, NHLDS, ISO 15189:2022, and HMIS 105 Section 9 Guidelines*

---

## 1\. Technical Framework & System Design Principles

This document establishes a rigorous, factual database and reporting dictionary for all **89 standard clinical parameters** currently performed or planned for integration.

This technical framework bridges the requirements of clinical client care with the administrative mandates of the Ugandan Ministry of Health. It is designed around two core architectural principles:

### A. Dynamic Reference Intervals (Biological Age/Sex Normalization)

Quantitative biochemical and hematological parameters are highly dependent on client physiology. The LIMS database must dynamically evaluate the `result_value` against a reference matrix that filters by the client's biological sex and age:

* **Adult or Child, Male (M, \>=12 Years)**  
* **Adult or Child, Female (F, \>=12 Years)**  
* **Pediatric (\<12 Years)**

### B. Automated Clinical Flags & Interpretive Legends

When a result is entered or captured from an automated analyzer, the reporting module must automatically compare the numeric value to the appropriate physiological range and append the correct flag:

* `L` (Low): Value is strictly below the normal reference interval.  
* `H` (High): Value is strictly above the normal reference interval.  
* `*` (Critical/Panic Value): Represents a life-threatening physiological extreme (e.g., severe hypokalemia or critical thrombocytopenia) that requires an immediate verbal alert to the ward.  
* `Severe Anemia Watch`: Automatically triggered for any hemoglobin value **strictly less than 8.0 g/dL** to align with national surveillance protocols.

---

## 2\. Comprehensive Parameter Reporting Specifications

Below is the complete dictionary for all 89 diagnostic parameters. Each parameter is mapped to its clinical nomenclature, standard units, biological reference intervals, flagging criteria, and official HMIS 105 Section 9 mapping requirements.

### SECTION 1: Hematology

#### A. Automated Complete Blood Count (CBC) Parameters

\*These parameters are mapped to automated multi-angle laser flow cytometry and impedance analyzer outputs. In line with the DEVICE\_PRESET rule, raw numeric values and machine flags ($H, L, *$) must be ingested directly into the database as-is.*

##### 1\. Total WBC Count (White Blood Cells)

* **Clinical Nomenclature**: Total White Blood Cell Count.  
* **Reporting Unit**: $10^3/\mu{L}$ (or $10^9/{L}$) .  
* **Reference Ranges**:  
  * Adult Male/Female: $4.0 - 11.0 \times 10^3/\mu    {L}$ .  
  * Pediatric (\<12 Years): $6.0 - 14.0     \times 10^3/\mu    {L}$ .
* **Clinical Flags**: $<4.0$ (`L`), $\>11.0$ (`H`) for adults; $<4.0$ (`L*`) represents a critical neutropenic alert state.  
* **HMIS 105 Section 9 Mapping**: Does not map to a standalone indicator (tracked locally under total CBC runs).

##### 2\. Red Blood Cells (RBC)

* **Clinical Nomenclature**: Red Blood Cell Count.  
* **Reporting Unit**: $10^6/\mu \text{L}$ (or $10^{12}/\text{L}$) .  
* **Reference Ranges**:  
  * Adult Male: $4.50 - 5.90 \times 10^6/\mu \text{L}$ .  
  * Adult Female: $4.00 - 5.20 \times 10^6/\mu \text{L}$ .  
  * Pediatric (\<12 Years): $4.00 - 5.20 \times 10^6/\mu \text{L}$ .
* **Clinical Flags**: Under reference limits (`L`), Over reference limits (`H`).  
* **HMIS 105 Section 9 Mapping**: N/A (Internal clinical tracking only).

##### 3\. Hemoglobin (Hb)

* **Clinical Nomenclature**: Hemoglobin.  
* **Reporting Unit**: $\text{g/dL}$ .  
* **Reference Ranges**:  
  * Adult Male: $13.5 - 17.5\text{ g/dL}$ .  
  * Adult Female: $12.0 - 15.5\text{ g/dL}$ .  
  * Pediatric (\<12 Years): $11.5 - 15.5\text{ g/dL}$ .
* **Clinical Flags**:  
  * `< Normal` (`L`), `> Normal` (`H`).  
  * **Severe Anemia Watch**: Any result **$<8.0 {g/dL}$** must automatically append the alert flag `L*` .
* **HMIS 105 Section 9 Mapping**: Mapped to **Severe Anemia (\<8.0 g/dL)**: *Section 9: Tested* and *Section 9: Abnormal (Severe Anemia)* .

##### 4\. Hematocrit (HCT)

* **Clinical Nomenclature**: Hematocrit / Packed Cell Volume (PCV) .  
* **Reporting Unit**: $%$ .  
* **Reference Ranges**:  
  * Adult Male: $41.0 - 50.0%$ .  
  * Adult Female: $36.0 - 46.0%$ .  
  * Pediatric (\<12 Years): $35.0 - 45.0%$ .
* **Clinical Flags**: Out of biological range (`L` or `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 5\. Mean Cell Volume (MCV)

* **Clinical Nomenclature**: Mean Corpuscular Volume .  
* **Reporting Unit**: $\text{fL}$ (Femtoliters) .  
* **Reference Ranges**:  
  * Adult Male/Female: $80.0 - 100.0\text{ fL}$ .  
  * Pediatric (\<12 Years): $77.0 - 95.0\text{ fL}$ .
* **Clinical Flags**: Microcytic anemia indicator (`<80.0` $ \rightarrow$ `L`), Macrocytic indicator (`>100.0` $ \rightarrow$ `H`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 6\. Mean Cell Hb (MCH)

* **Clinical Nomenclature**: Mean Corpuscular Hemoglobin .  
* **Reporting Unit**: $\text{pg}$ (Picograms) .  
* **Reference Ranges**:  
  * Adult Male/Female: $27.0 - 33.0\text{ pg}$ .  
  * Pediatric (\<12 Years): $23.0 - 31.0\text{ pg}$ .
* **Clinical Flags**: Hypochromia indicator (`<27.0` $ \rightarrow$ `L`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 7\. Mean Cell Hb Conc (MCHC)

* **Clinical Nomenclature**: Mean Corpuscular Hemoglobin Concentration .  
* **Reporting Unit**: $\text{g/dL}$ .  
* **Reference Ranges**:  
  * Adult Male/Female: $32.0 - 36.0\text{ g/dL}$ .  
  * Pediatric (\<12 Years): $28.0 - 33.0\text{ g/dL}$ .
* **Clinical Flags**: Out of range (`L` or `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 8\. Platelets Count (PLT)

* **Clinical Nomenclature**: Platelet Count (historically tracked as *Platelets Conut* in older templates) .  
* **Reporting Unit**: $10^3/\mu \text{L}$ (or $10^9/\text{L}$) .  
* **Reference Ranges**:  
  * All client Groups: $150 - 400 \times 10^3/\mu \text{L}$ .
* **Clinical Flags**:  
  * Thrombocytopenia: $<150$ (`L`) .  
  * Thrombocytosis: $\>400$ (`H`) .  
  * **Critical Panic Limit**: **$<50 \times 10^3/\mu \text{L}$** (`L*`) requires immediate emergency notification due to spontaneous bleeding risk .
* **HMIS 105 Section 9 Mapping**: N/A .

##### 9\. Neutrophils (%) \[Relative Count\]

* **Clinical Nomenclature**: Neutrophil Percentage .  
* **Reporting Unit**: $%$ .  
* **Reference Ranges**:  
  * Adult Male/Female: $40.0 - 75.0%$ .  
  * Pediatric (\<12 Years): $40.0 - 65.0%$ .
* **Clinical Flags**: Neutropenia (`L`), Neutrophilia (`H`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 10\. Lymphocytes (%) \[Relative Count\]

* **Clinical Nomenclature**: Lymphocyte Percentage .  
* **Reporting Unit**: $%$ .  
* **Reference Ranges**:  
  * Adult Male/Female: $20.0 - 45.0%$ .  
  * Pediatric (\<12 Years): $19.2 - 49.5%$ .
* **Clinical Flags**: Lymphopenia (`L`), Lymphocytosis (`H`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 11\. Monocytes (%) \[Relative Count\]

* **Clinical Nomenclature**: Monocyte Percentage .  
* **Reporting Unit**: $%$ .  
* **Reference Ranges**:  
  * Adult Male/Female: $2.0 - 10.0%$ .  
  * Pediatric (\<12 Years): $4.5 - 12.1%$ .
* **Clinical Flags**: Monocytosis (`>10.0` $ \rightarrow$ `H`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 12\. Eosinophils (%) \[Relative Count\]

* **Clinical Nomenclature**: Eosinophil Percentage .  
* **Reporting Unit**: $%$ .  
* **Reference Ranges**:  
  * Adult Male/Female: $1.0 - 6.0%$ .  
  * Pediatric (\<12 Years): $1.0 - 12.0%$ .
* **Clinical Flags**: Eosinophilia (`>6.0` $ \rightarrow$ `H` for adults; `>12.0` $ \rightarrow$ `H` for pediatrics) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 13\. Basophils (%) \[Relative Count\]

* **Clinical Nomenclature**: Basophil Percentage .  
* **Reporting Unit**: $%$ .  
* **Reference Ranges**:  
  * All client Groups: $0.0 - 1.0%$ .
* **Clinical Flags**: Basophilia (`>1.0` $ \rightarrow$ `H`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 14\. Neutrophils (Absolute Count)

* **Clinical Nomenclature**: Absolute Neutrophil Count (ANC) .  
* **Reporting Unit**: $10^9/\mu \text{L}$ (or $10^9/\text{L}$) .  
* **Reference Ranges**:  
  * Adult Male/Female: $2.00 - 7.50 \times 10^9/\mu \text{L}$ .  
  * Pediatric (\<12 Years): $2.00 - 6.00 \times 10^9/\mu \text{L}$ .
* **Clinical Flags**: ANC $<1.5 \times 10^9/\mu \text{L}$ flagged as severe clinically significant neutropenia (`L`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 15\. Lymphocytes (Absolute Count)

* **Clinical Nomenclature**: Absolute Lymphocyte Count .  
* **Reporting Unit**: $10^9/\mu \text{L}$ .  
* **Reference Ranges**:  
  * Adult Male/Female: $1.00 - 4.00 \times 10^9/\mu \text{L}$ .  
  * Pediatric (\<12 Years): $5.00 - 8.50 \times 10^9/\mu \text{L}$ .
* **Clinical Flags**: Out of biological range (`L` or `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### Monocytes (Absolute Count)

* **Clinical Nomenclature**: Absolute Monocyte Count .  
* **Reporting Unit**: $10^9/\mu \text{L}$ .  
* **Reference Ranges**:  
  * Adult Male/Female: $0.20 - 0.80 \times 10^9/\mu \text{L}$ .  
  * Pediatric (\<12 Years): $0.70 - 1.50 \times 10^9/\mu \text{L}$ .
* **Clinical Flags**: Monocytosis (`>0.80` $ \rightarrow$ `H`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 17\. Eosinophils (Absolute Count)

* **Clinical Nomenclature**: Absolute Eosinophil Count .  
* **Reporting Unit**: $10^9/\mu \text{L}$ .  
* **Reference Ranges**:  
  * Adult Male/Female: $0.04 - 0.40 \times 10^9/\mu \text{L}$ .  
  * Pediatric (\<12 Years): $0.30 - 0.80 \times 10^9/\mu \text{L}$ .
* **Clinical Flags**: Absolute eosinophilia (`>0.40` $ \rightarrow$ `H` for adults) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 18\. Basophils (Absolute Count)

* **Clinical Nomenclature**: Absolute Basophil Count .  
* **Reporting Unit**: $10^9/\mu \text{L}$ .  
* **Reference Ranges**:  
  * Adult Male/Female: $0.00 - 0.10 \times 10^9/\mu \text{L}$ .  
  * Pediatric (\<12 Years): $0.00 - 0.50 \times 10^9/\mu \text{L}$ .
* **Clinical Flags**: Basophilia (`>0.10` $ \rightarrow$ `H`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 19\. RBC Distribution Width (RDW)

* **Clinical Nomenclature**: Red Cell Distribution Width (tracked as *RBC Distributuion width* in older templates) .  
* **Reporting Unit**: $%$ .  
* **Reference Ranges**:  
  * All client Groups: $11.0 - 16.0%$ .
* **Clinical Flags**: Anisocytosis (`>16.0%` $ \rightarrow$ `H`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 20\. Thrombocrit (PCT)

* **Clinical Nomenclature**: Plateletcrit / Thrombocrit .  
* **Reporting Unit**: $%$ .  
* **Reference Ranges**:  
  * All client Groups: $0.16 - 0.33%$ .
* **Clinical Flags**: Out of biological range (`L` or `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 21\. Mean Platelet Volume (MPV)

* **Clinical Nomenclature**: Mean Platelet Volume .  
* **Reporting Unit**: $\text{fL}$ (Femtoliters) .  
* **Reference Ranges**:  
  * All client Groups: $6.0 - 10.0\text{ fL}$ .
* **Clinical Flags**: Giant platelet morphology indicator (`>10.0` $ \rightarrow$ `H`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 22\. PLT Distribution Width (PDW)

* **Clinical Nomenclature**: Platelet Distribution Width .  
* **Reporting Unit**: $%$ .  
* **Reference Ranges**:  
  * All client Groups: $12.0 - 18.0%$ .
* **Clinical Flags**: Out of biological range (`L` or `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

#### B. Other Manual Hematology & Coagulation Parameters

##### 23\. E.S.R (Erythrocyte Sedimentation Rate)

* **Clinical Nomenclature**: Erythrocyte Sedimentation Rate (Westergren) .  
* **Reporting Unit**: $\text{mm/hour}$ .  
* **Reference Ranges**:  
  * Adult Male (\<=50 Years): $<15\text{ mm/hr}$ .  
  * Adult Male (\>50 Years): $<20\text{ mm/hr}$ .  
  * Adult Female (\<=50 Years): $<20\text{ mm/hr}$ .  
  * Adult Female (\>50 Years): $<30\text{ mm/hr}$ .  
  * Pediatric (\<12 Years): $3.0 - 13.0\text{ mm/hr}$ .
* **Clinical Flags**: Inflammatory escalation indicator (`> Normal` $ \rightarrow$ `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 24\. Aptt (Activated Partial Thromboplastin Time)

* **Clinical Nomenclature**: Activated Partial Thromboplastin Time (APTT) .  
* **Reporting Unit**: Seconds .  
* **Reference Ranges**:  
  * All client Groups: $25.0 - 35.0\text{ seconds}$ .
* **Clinical Flags**: Coagulopathy risk / Heparinization state (`>35.0 seconds` $ \rightarrow$ `H`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 25\. Prothrombin Time (PT)

* **Clinical Nomenclature**: Prothrombin Time .  
* **Reporting Unit**: Seconds .  
* **Reference Ranges**:  
  * All client Groups: $11.0 - 13.5\text{ seconds}$.
* **Clinical Flags**: Bleeding disorder / Extrinsic pathway deficiency (`>13.5 seconds` $ \rightarrow$ `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 26\. International Normalized Ratio (INR)

* **Clinical Nomenclature**: International Normalized Ratio .  
* **Reporting Unit**: Calculated ratio (dimensionless) .  
* **Reference Ranges**:  
  * Standard Normal Range: $0.8 - 1.2$ .  
  * Therapeutic Range (Warfarin therapy): $2.0 - 3.0$ .
* **Clinical Flags**: High clotting risk (`<0.8` $ \rightarrow$ `L`), High bleeding risk (`>1.2` for standard or `>3.0` in therapy $ \rightarrow$ `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 27\. Bleeding Time (BT)

* **Clinical Nomenclature**: Bleeding Time (Duke / Ivy Method) .  
* **Reporting Unit**: Minutes .  
* **Reference Ranges**:  
  * Duke Method: $1.0 - 5.0    ext{ minutes}$.  
  * Ivy Method: $2.0 - 9.0    ext{ minutes}$.
* **Clinical Flags**: Platelet dysfunction / Bleeding diathesis (`> Normal` $ \rightarrow$ `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 28\. Clotting Time (CT)

* **Clinical Nomenclature**: Clotting Time (Lee-White / Capillary Tube) .  
* **Reporting Unit**: Minutes .  
* **Reference Ranges**:  
  * Lee-White Method: $5.0 - 11.0    ext{ minutes}$.  
  * Capillary Tube Method: $2.0 - 6.0    ext{ minutes}$.
* **Clinical Flags**: Clotting factor deficiency (`> Normal` $ \rightarrow$ `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 29\. Reticulocyte Count

* **Clinical Nomenclature**: Reticulocyte Percentage (supravital staining) .  
* **Reporting Unit**: $%$ (Percentage of total erythrocytes) .  
* **Reference Ranges**:  
  * Adult Male/Female: $0.5 - 1.5%$ .  
  * Newborn: $2.0 - 6.0%$ .
* **Clinical Flags**: Bone marrow failure (`<0.5%` $ \rightarrow$ `L`), Hemolytic compensation / Reticulocytosis (`>1.5%` $ \rightarrow$ `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 30\. Sickling Test (Sodium Metabisulfite)

* **Clinical Nomenclature**: Sickling Test / Hemoglobin Solubility .  
* **Reporting Unit**: Qualitative .  
* **Reporting Format**: `Positive` (sickling observed) or `Negative` (no sickling seen) .  
* **Clinical Flags**: `Positive` results must automatically append an alert flag (`0xE2 0x9A 0xA0`).  
* **HMIS 105 Section 9 Mapping**: N/A .

---

### SECTION 2: Serology & Clinical Immunology

*This department processes rapid immunochromatographic assays, latex agglutination cards, and cell counting instruments .*

##### 31\. WIDAL (Salmonella Typhi Agglutination)

* **Clinical Nomenclature**: Widal Test .  
* **Reporting Unit**: `Positive` or `Negative`, Reciprocal titer ratios . 
* **Primary Reporting Format - qualitative:**  `Positive` or `Negative`
* **Secondary Reporting Format - Semi-quantitative**: Must be disaggregated by O and H antigens:  
  * `TO (S. typhi O)`: e.g., `Non-Reactive`, `1:40`, `1:80`, `1:160`, `1:320` .  
  * `TH (S. typhi H)`: e.g., `Non-Reactive`, `1:40`, `1:80`, `1:160`, `1:320` .
* **Clinical Flags**: Titers **$\ge 1:160$** for either antigen are clinically significant and flagged  (`0xE2 0x9A 0xA0`) in endemic regions .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 32\. VDRL/RPR (Syphilis Screening)

* **Clinical Nomenclature**: VDRL (Venereal Disease Research Lab) / RPR (Rapid Plasma Reagin) .  
* **Reporting Unit**: Qualitative and semi-quantitative dilutions .  
* **Reporting Format**:  
  * Standard Negative: `Non-Reactive` .  
  * Standard Positive: `Reactive` accompanied by dilution titer (e.g., `Reactive 1:2`, `Reactive 1:8`, `Reactive 1:16`, `Reactive 1:64`) .
* **Clinical Flags**: `Reactive` results automatically flag with alert (`0xE2 0x9A 0xA0`) .  
* **HMIS 105 Section 9 Mapping**: Mapped to **Syphilis Tested & Syphilis Positive**: *Section 9: Tested* and *Section 9: Positive* .

##### 33\. HIV (MoH Three-Test Algorithm)

* **Clinical Nomenclature**: HIV Rapid Diagnostic Test .  
* **Methodology**: **Determine** (Screening) $ \rightarrow$ **Stat-Pak** (Confirmatory) $ \rightarrow$ **SD Bioline** (Tie-breaker) .  
* **Reporting Options**:  
  * `Reactive`: Positive across the algorithmic pathway .  
  * `Non-Reactive`: Negative on screening .  
  * `Inconclusive`: Discrepant results with a discrepant tie-breaker .
* **Clinical Flags**: `Reactive` results automatically append abnormal flag (`0xE2 0x9A 0xA0`).  
* **HMIS 105 Section 9 Mapping**: Mapped to **HIV Testing Services**: *Section 9: Tested* and *Section 9: Positive*, disaggregated strictly by age band and sex .

##### 34\. HBsAg (Hepatitis B)

* **Clinical Nomenclature**: Hepatitis B Surface Antigen .  
* **Reporting Options**: `Positive` or `Negative` .  
* **Clinical Flags**: `Positive` results flagged as Abnormal (`0xE2 0x9A 0xA0`).  
* **HMIS 105 Section 9 Mapping**: Mapped to **HBsAg Tested & Positive** .

##### 35\. BAT (Brucella Antigen Test)

* **Clinical Nomenclature**: Brucella Agglutination Test .  
* **Reporting Options**: Qualitative `Positive` or `Negative`, or reciprocal titers (e.g., `Reactive 1:80`, `Reactive 1:160`).  
* **Clinical Flags**: `Positive` / Titers $\ge 1:80$ flagged  (`0xE2 0x9A 0xA0`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 36\. RF (Rheumatoid Factor)

* **Clinical Nomenclature**: Rheumatoid Factor .  
* **Reporting Options**: `Positive` or `Negative` (alternatively `Reactive` / `Non-Reactive`) .  
* **Clinical Flags**: `Positive` flagged  (`0xE2 0x9A 0xA0`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 37\. HCG Urine

* **Clinical Nomenclature**: Urine Pregnancy Test .  
* **Reporting Options**: `Positive` or `Negative` .  
* **Clinical Flags**: None (handled purely as qualitative diagnostic indicators) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 38\. HCG Blood

* **Clinical Nomenclature**: Serum Quantitative Beta-HCG .  
* **Reporting Unit**: $\text{mIU/mL}$ .  
* **Reference Ranges**:  
  * Non-Pregnant Female: $<5.0\text{ mIU/mL}$ .  
  * Pregnant Female: $\ge 25.0\text{ mIU/mL}$ (with rapid doubling times) .
* **Clinical Flags**: Under non-pregnant baseline threshold (`>=5.0` in non-pregnant history $ \rightarrow$ `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 39\. H.Pylori Ag (Stool Antigen)

* **Clinical Nomenclature**: Helicobacter pylori Stool Antigen .  
* **Reporting Options**: `Positive` or `Negative` .  
* **Clinical Flags**: `Positive` flagged (`0xE2 0x9A 0xA0`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 40\. H.Pylori Ab (Serum Antibody)

* **Clinical Nomenclature**: Helicobacter pylori Serum Antibody .  
* **Reporting Options**: `Positive` or `Negative` .  
* **Clinical Flags**: `Positive` flagged  (`0xE2 0x9A 0xA0`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 41\. Malaria RDT

* **Clinical Nomenclature**: Malaria Rapid Diagnostic Test .  
* **Reporting Options**: `Positive` or `Negative` .  
* **Clinical Flags**: `Positive` flagged  (`0xE2 0x9A 0xA0`).  
* **HMIS 105 Section 9 Mapping**: Mapped to **mRDT (Malaria RDT)**: *Section 9: Tested* and *Section 9: Positive* .

##### 42\. TB LAM (Urine Tuberculosis LAM)

* **Clinical Nomenclature**: Urine Lipoarabinomannan Test .  
* **Reporting Options**: `Positive` or `Negative` .  
* **Clinical Flags**: `Positive` flagged  (`0xE2 0x9A 0xA0`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 43\. COVID19RDT

* **Clinical Nomenclature**: COVID-19 Rapid Antigen Test .  
* **Reporting Options**: `Positive` or `Negative` .  
* **Clinical Flags**: `Positive` flagged  (`0xE2 0x9A 0xA0`).  
* **HMIS 105 Section 9 Mapping**: Mapped to **COVID-19 RDT Tested & Positive** .

##### 44\. CD4 COUNT

* **Clinical Nomenclature**: Absolute CD4 T-Cell Count .  
* **Reporting Unit**: $\text{cells/}\mu \text{L}$ .  
* **Reference Ranges**:  
  * Adult Normal: $500 - 1500\text{ cells/}\mu \text{L}$ .
* **Clinical Flags**:  
  * Severe Immunosuppression: $<350\text{ cells/}\mu \text{L}$ (`L`) .  
  * **Advanced HIV Disease (AHD) Alert**: **$<200\text{ cells/}\mu \text{L}$** (`L*`) requires immediate diagnostic workup for opportunistic infections .
* **HMIS 105 Section 9 Mapping**: Mapped to **CD4 Count Tested** and **CD4 \<200** (Advanced Disease surveillance) .

##### 45\. CrAg (Cryptococcal Antigen)

* **Clinical Nomenclature**: Cryptococcal Antigen Lateral Flow Assay .  
* **Reporting Options**: `Positive` or `Negative` .  
* **Clinical Flags**: `Positive` automatically triggers critical/panic flag (`*` / `H*`) due to meningitis risk .  
* **HMIS 105 Section 9 Mapping**: Mapped to **CrAg Tested & Positive** .

##### 46\. HCV Ab (Hepatitis C)

* **Clinical Nomenclature**: Hepatitis C Virus Rapid Antibody .  
* **Reporting Options**: `Positive` or `Negative`.  
* **Clinical Flags**: `Positive` flagged  (`0xE2 0x9A 0xA0`).  
* **HMIS 105 Section 9 Mapping**: Mapped to **HCV Tested & Positive** .

##### 47\. TPHA (Confirmatory Syphilis Test)

* **Clinical Nomenclature**: Treponema Pallidum Hemagglutination Assay .  
* **Reporting Options**: qualitative `Reactive` or `Non-Reactive`, or reciprocal titers (e.g., `Reactive 1:80`, `Reactive 1:320`).  
* **Clinical Flags**: `Reactive` flagged  (`0xE2 0x9A 0xA0`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 48\. ASO Titer (Anti-Streptolysin O)

* **Clinical Nomenclature**: Anti-Streptolysin O Titer .  
* **Reporting Unit**: $\text{IU/mL}$ (International Units per milliliter) .  
* **Reference Ranges**:  
  * All client Groups: $<200\text{ IU/mL}$ .
* **Clinical Flags**: Rheumatic Fever / Post-streptococcal sequelae risk (`>=200 IU/mL` $ \rightarrow$ `H`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 49\. Alpha-Fetoprotein (AFP)

* **Clinical Nomenclature**: Alpha-Fetoprotein .  
* **Reporting Unit**: $\text{ng/mL}$ .  
* **Reference Ranges**:  
  * Non-Pregnant Adult Normal: $<10.0\text{ ng/mL}$ .
* **Clinical Flags**: Hepatocellular carcinoma / Germ cell tumor marker warning (`>=10.0 ng/mL` $ \rightarrow$ `H`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

---

### SECTION 3: Clinical Biochemistry

*These biochemical tests generate quantitative, continuous numeric values and require automated or semi-automated clinical chemistry analyzer outputs .*

##### 50\. FBS (Fasting Blood Sugar)

* **Clinical Nomenclature**: Fasting Blood Sugar .  
* **Reporting Unit**: $\text{mmol/L}$ (SI Standard) .  
* **Reference Ranges**:  
  * All client Groups: $3.9 - 5.5\text{ mmol/L}$ (Conversion: $\text{mg/dL} \div 18.018$) .
* **Clinical Flags**:  
  * Hypoglycemia: $<3.9\text{ mmol/L}$ (`L*` - Critical/Panic Alert) .  
  * Impaired Fasting Glucose: $5.6 - 6.9\text{ mmol/L}$ (`H`) .  
  * Diabetic Threshold: $\ge 7.0\text{ mmol/L}$ (`H*` - Diagnostic Indicator) .
* **HMIS 105 Section 9 Mapping**: N/A .

##### 51\. RBS (Random Blood Sugar)

* **Clinical Nomenclature**: Random Blood Sugar .  
* **Reporting Unit**: $\text{mmol/L}$ .  
* **Reference Ranges**:  
  * All client Groups: $3.9 - 7.8\text{ mmol/L}$ .
* **Clinical Flags**:  
  * Hypoglycemia: $<3.9\text{ mmol/L}$ (`L*` - Critical Alert) .  
  * Impaired Glucose Tolerance: $7.9 - 11.0\text{ mmol/L}$ (`H`) .  
  * Diabetic Threshold: $\ge 11.1\text{ mmol/L}$ (`H*` - Diagnostic Indicator) .
* **HMIS 105 Section 9 Mapping**: N/A .

##### 52\. Serum Creatinine

* **Clinical Nomenclature**: Creatinine .  
* **Reporting Unit**: $\mu \text{mol/L}$ .  
* **Reference Ranges**:  
  * Adult Male: $60 - 110\text{ }\mu \text{mol/L}$ .  
  * Adult Female: $45 - 90\text{ }\mu \text{mol/L}$ .  
  * Pediatric (\<12 Years): $20 - 60\text{ }\mu \text{mol/L}$ .
* **Clinical Flags**: Renal impairment / acute kidney injury (`> Normal` $ \rightarrow$ `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 53\. Serum Urea

* **Clinical Nomenclature**: Urea .  
* **Reporting Unit**: $\text{mmol/L}$ .  
* **Reference Ranges**:  
  * All client Groups: $2.5 - 7.8\text{ mmol/L}$ .
* **Clinical Flags**: Uremia / Renal clearance failure (`>7.8` $ \rightarrow$ `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 54\. Serum Uric Acid

* **Clinical Nomenclature**: Uric Acid .  
* **Reporting Unit**: $\mu \text{mol/L}$ .  
* **Reference Ranges**:  
  * Adult Male: $200 - 430\text{ }\mu \text{mol/L}$ .  
  * Adult Female: $140 - 360\text{ }\mu \text{mol/L}$ .
* **Clinical Flags**: Hyperuricemia / Gout risk (`> Normal` $ \rightarrow$ `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 55\. ALT / SGPT (Alanine Aminotransferase)

* **Clinical Nomenclature**: Alanine Aminotransferase (ALT) .  
* **Reporting Unit**: $\text{U/L}$ (Units per Liter) .  
* **Reference Ranges**:  
  * Adult Male: $<41\text{ U/L}$ .  
  * Adult Female: $<31\text{ U/L}$ .  
  * Pediatric (\<12 Years): $<35\text{ U/L}$ .
* **Clinical Flags**: Hepatocellular injury / Hepatitis (`> Normal` $ \rightarrow$ `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 56\. AST / SGOT (Aspartate Aminotransferase)

* **Clinical Nomenclature**: Aspartate Aminotransferase (AST) .  
* **Reporting Unit**: $\text{U/L}$ .  
* **Reference Ranges**:  
  * Adult Male: $<37\text{ U/L}$ .  
  * Adult Female: $<31\text{ U/L}$ .  
  * Pediatric (\<12 Years): $<40\text{ U/L}$ .
* **Clinical Flags**: Hepatic / Cardiac injury (`> Normal` $ \rightarrow$ `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 57\. Alkaline Phosphatase (ALP)

* **Clinical Nomenclature**: Alkaline Phosphatase .  
* **Reporting Unit**: $\text{U/L}$ .  
* **Reference Ranges**:  
  * Adult Male: $40 - 130\text{ U/L}$ .  
  * Adult Female: $35 - 105\text{ U/L}$ .  
  * Pediatric (\<12 Years): Up to $350\text{ U/L}$ (normally elevated due to active bone osteoblast activity) .
* **Clinical Flags**: Cholestatic liver obstruction / Bone disorders (`> Normal` $ \rightarrow$ `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 58\. Total Bilirubin

* **Clinical Nomenclature**: Total Bilirubin .  
* **Reporting Unit**: $\mu \text{mol/L}$ .  
* **Reference Ranges**:  
  * All client Groups: $5.0 - 21.0\text{ }\mu \text{mol/L}$ .
* **Clinical Flags**: Hyperbilirubinemia / Jaundice (`>21.0` $ \rightarrow$ `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 59\. Direct Bilirubin

* **Clinical Nomenclature**: Direct Bilirubin (Conjugated Bilirubin) .  
* **Reporting Unit**: $\mu \text{mol/L}$ .  
* **Reference Ranges**:  
  * All client Groups: $<5.0\text{ }\mu \text{mol/L}$ .  
  * All client Groups: $<5.0    \mu    \text{mol/L}$ .
* **Clinical Flags**: Post-hepatic biliary tree obstruction (`>=5.0` $ \rightarrow$ `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 60\. Total Protein

* **Clinical Nomenclature**: Total Protein .  
* **Reporting Unit**: $\text{g/dL}$ (or $\text{g/L}$) .  
* **Reference Ranges**:  
  * All client Groups: $6.0 - 8.0\text{ g/dL}$ (60 - 80 g/L) .
* **Clinical Flags**: Dehydration / Myeloma indicators (`>8.0` $ \rightarrow$ `H`), Liver synthetic failure / Nephrotic leak (`<6.0` $ \rightarrow$ `L`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 61\. Serum Albumin

* **Clinical Nomenclature**: Albumin .  
* **Reporting Unit**: $\text{g/dL}$ (or $\text{g/L}$) .  
* **Reference Ranges**:  
  * All client Groups: $3.5 - 5.0\text{ g/dL}$ (35 - 50 g/L) .
* **Clinical Flags**: Hypoalbuminemia / Severe malnutrition (`<3.5` $ \rightarrow$ `L`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 62\. Total Cholesterol

* **Clinical Nomenclature**: Total Cholesterol .  
* **Reporting Unit**: $\text{mmol/L}$ .  
* **Reference Ranges**:  
  * Standard Normal Range: $<5.2\text{ mmol/L}$ .
* **Clinical Flags**:  
  * Borderline High: $5.2 - 6.2\text{ mmol/L}$ (`H`) .  
  * High Cardiovascular Risk: $\>6.2\text{ mmol/L}$ (`H*`) .
* **HMIS 105 Section 9 Mapping**: N/A .

##### 63\. Serum Potassium (K+)

* **Clinical Nomenclature**: Potassium .  
* **Reporting Unit**: $\text{mmol/L}$ .  
* **Reference Ranges**:  
  * All client Groups: $3.5 - 5.1\text{ mmol/L}$ .
* **Clinical Flags**:  
  * Out of range: `<3.5` (`L`), `>5.1` (`H`) .  
  * **Critical Hypokalemia**: **$<3.0\text{ mmol/L}$** (`L*` - Panic alert for cardiac arrest) .  
  * **Critical Hyperkalemia**: **$\>6.0\text{ mmol/L}$** (`H*` - Panic alert for cardiac arrest) .
* **HMIS 105 Section 9 Mapping**: N/A .

##### 64\. Serum Sodium (Na+)

* **Clinical Nomenclature**: Sodium .  
* **Reporting Unit**: $\text{mmol/L}$ .  
* **Reference Ranges**:  
  * All client Groups: $135 - 145\text{ mmol/L}$ .
* **Clinical Flags**:  
  * Out of range: `<135` (`L`), `>145` (`H`) .  
  * **Critical Hyponatremia**: **$<125\text{ mmol/L}$** (`L*` - Panic alert for cerebral edema) .  
  * **Critical Hypernatremia**: **$\>155\text{ mmol/L}$** (`H*` - Panic alert) .
* **HMIS 105 Section 9 Mapping**: N/A .

##### 65\. Serum Chloride (Cl-)

* **Clinical Nomenclature**: Chloride .  
* **Reporting Unit**: $\text{mmol/L}$ .  
* **Reference Ranges**:  
  * All client Groups: $98 - 107\text{ mmol/L}$ .
* **Clinical Flags**: Acid-base disturbance indicator (`<98` $ \rightarrow$ `L`, `>107` $ \rightarrow$ `H`).  
* **HMIS 105 Section 9 Mapping**: N/A .

---

### SECTION 4: Urinalysis Profile

*Urinalysis must be reported as a unified, tripartite profile. On client printouts, Urinalysis must always be placed as the final, bottom section .*

#### A. Urinalysis Macroscopy

##### 66\. Macroscopy (Physical Profile)

* **Clinical Nomenclature**: Urine Physical Examination .  
* **Reporting Sub-fields**:  
  * `Appearance / Turbidity`: `Clear`, `Slightly Turbid`, or `Turbid` .  
  * `Color`: `Straw`, `Yellow` , `Amber`, `Red` (Hematuria), or `Brown`.
* **Clinical Flags**: `Turbid` and `Red` colors should append abnormal flags (`0xE2 0x9A 0xA0`).  
* **HMIS 105 Section 9 Mapping**: N/A .

#### B. Urinalysis Dry Chemistry Dipstick

*Dipstick values are processed semi-quantitatively to maintain clinical relevance rather than raw color scales . Any non-zero chemical finding is clinically significant .*

##### 67\. Specific Gravity (S.G)

* **Clinical Nomenclature**: Specific Gravity .  
* **Reporting Unit**: Numeric ratio .  
* **Reference Ranges**: $1.005 - 1.030$ .  
* **Clinical Flags**: Concentrated urine (Dehydration): `>1.030` (`H`); Dilute urine (DI/Overhydration): `<1.005` (`L`).

##### 68\. PH

* **Clinical Nomenclature**: Urine pH .  
* **Reporting Unit**: pH scale (dimensionless) .  
* **Reference Ranges**: $5.0 - 8.5$ .  
* **Clinical Flags**: Acidic (`<5.0` $ \rightarrow$ `L`), Alkaline (`>8.5` $ \rightarrow$ `H`).

##### 69\. Proteins (Albuminuria Screening)

* **Clinical Nomenclature**: Urine Protein .  
* **Reporting Format**: `Nil` , `Trace`, `1+` (\~30 mg/dL), `2+` (\~100 mg/dL), `3+` (~~300 mg/dL), or `4+` (~~$\ge 1000$ mg/dL).  
* **Clinical Flags**: **$\ge 1+$** must trigger the flag (`0xE2 0x9A 0xA0`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 70\. Glucose (Glucosuria Screening)

* **Clinical Nomenclature**: Urine Glucose .  
* **Reporting Format**: `Nil` , `Trace`, `1+`, `2+`, `3+`, `4+`.  
* **Clinical Flags**: **$\ge 1+$** triggers the flag (`0xE2 0x9A 0xA0`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 71\. Bilirubin (Bilirubinuria)

* **Clinical Nomenclature**: Urine Bilirubin .  
* **Reporting Format**: `Nil` , `1+`, `2+`, `3+`.  
* **Clinical Flags**: Any non-zero finding ($\ge 1+$) is abnormal and flagged as High (`0xE2 0x9A 0xA0`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 72\. Urobilinogen

* **Clinical Nomenclature**: Urine Urobilinogen .  
* **Reporting Format**: `Normal` (or `0.2 EU/dL`), `1+`, `2+`, `3+`.  
* **Clinical Flags**: **$\ge 1+$** triggers the flag (`0xE2 0x9A 0xA0`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 73\. Ketones (Ketonuria)

* **Clinical Nomenclature**: Urine Ketones .  
* **Reporting Format**: `Nil` , `Trace`, `1+`, `2+`, `3+`.  
* **Clinical Flags**: Any non-zero finding is abnormal and flagged as High (`0xE2 0x9A 0xA0`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 74\. Blood (Hematuria/Hemoglobinuria)

* **Clinical Nomenclature**: Urine Blood .  
* **Reporting Format**: `Nil` , `Trace`, `1+`, `2+`, `3+`.  
* **Clinical Flags**: Any non-zero finding is abnormal and flagged as High (`0xE2 0x9A 0xA0`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 75\. Nitrates (Nitrite Screening)

* **Clinical Nomenclature**: Urine Nitrite .  
* **Reporting Format**: `Positive` or `Negative` (or `Nil`) .  
* **Clinical Flags**: `Positive` results indicate gram-negative bacteriuria and flag as Abnormal (`0xE2 0x9A 0xA0`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 76\. Leukocytes (Leukocyte Esterase)

* **Clinical Nomenclature**: Urine Leukocyte Esterase .  
* **Reporting Format**: `Nil`, `Trace`, `1+`, `2+` , `3+`.  
* **Clinical Flags**: **$\ge 1+$** triggers the  flag (`0xE2 0x9A 0xA0`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

#### C. Urinalysis Microscopy

##### 77\. Microscopy (Sediment Cytology)

* **Clinical Nomenclature**: Urine Microscopic Sediment Analysis .  
* **Reporting Sub-fields**:  
  * `Pus Cells (WBCs)`: Numeric per high-power field (e.g., `0-2 / hpf`, `10-15 / hpf`) . Normal: $<5\text{ WBCs/hpf}$.  
  * `Red Blood Cells (RBCs)`: Numeric per high-power field (e.g., `0-1 / hpf`, `5-10 / hpf`) . Normal: $<3\text{ RBCs/hpf}$.  
  * `Epithelial Cells`: Categorical: `Few`, `Moderate`, or `Plenty` .  
  * `Casts`: Type-specific identification (e.g., `Nil`, `Hyaline Casts (0-1 / lpf)`, `Granular Casts`) .  
  * `Crystals`: Type-specific identification (e.g., `Calcium oxalate (++)`, `Triple phosphate (++)`, `Nil`) .
* **Clinical Flags**: Pus cells $\ge 5$ / hpf or RBCs $\ge 3$ / hpf are flagged as Abnormal (`0xE2 0x9A 0xA0`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

---

### SECTION 5: Parasitology & Stool Diagnostics

*Governed by manual microscopic slide evaluations for gastrointestinal and hematological parasitic pathogens .*

##### 78\. Blood smear Mps (Malaria Microscopy)

* **Clinical Nomenclature**: Malaria Blood Smear (MPS) Thick & Thin .  
* **Reporting Format**:  
  * Standard Negative: `No malaria parasites seen` (NMPS) .  
  * Standard Positive: Reported using the MoH plus system:  
    * `1+` (1-10 parasites per 100 thick-film fields) .  
    * `2+` (11-100 parasites per 100 thick-film fields) .  
    * `3+` (1-10 parasites per single thick-film field) .  
    * `4+` (\>10 parasites per single thick-film field) .
  * *Thin Smear Species Identification*: E.g., `Plasmodium falciparum` (predominant at 97% nationally), `P. vivax`, or `P. malariae` .
* **Clinical Flags**: Any positive finding automatically triggers an abnormal alert (`0xE2 0x9A 0xA0`).  
* **HMIS 105 Section 9 Mapping**: Mapped to **Malaria Microscopy (BS)**: *Section 9: Tested* and *Section 9: Positive* .

##### 79\. Stool Analysis (Macroscopy)

* **Clinical Nomenclature**: Stool Physical Profile .  
* **Reporting Sub-fields**:  
  * `Consistency`: `Formed`, `Semi-formed`, `Loose`, or `Watery` .  
  * `Blood`: `Present` or `Absent` .  
  * `Mucus`: `Present` or `Absent` .  
  * `Worms`: Type-specific identification if present (e.g., `Ascaris lumbricoides`, `Nil`) .
* **Clinical Flags**: Consistency of `Loose`/`Watery`, or `Present` blood or mucus, triggers flag (`0xE2 0x9A 0xA0`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 80\. Stool Analysis (Microscopy)

* **Clinical Nomenclature**: Stool Wet Mount Microscopic Examination .  
* **Reporting Format**: Detailed identification of vegetative, cyst, or ova structures:  
  * Standard Negative: `No ova, cysts, or trophozoites seen` .  
  * Standard Positive: Explicit pathogen genus/species (e.g., `E. histolytica cysts`, `G. lamblia cysts`, `Hookworm ova`, `Schistosoma mansoni ova`, `A. lumbricoides ova`) .
* **Clinical Flags**: Pathogen presence automatically flags  (`0xE2 0x9A 0xA0`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 81\. Stool Occult Blood

* **Clinical Nomenclature**: Fecal Occult Blood Test (FOBT) .  
* **Reporting Options**: `Positive` or `Negative`.  
* **Clinical Flags**: `Positive` flagged (`0xE2 0x9A 0xA0`) due to risk of gastrointestinal bleeding/malignancy.  
* **HMIS 105 Section 9 Mapping**: N/A .

---

### SECTION 6: Microbiology & Tuberculosis

*Handles diagnostic pathogen staining, isolation, and antimicrobial drug susceptibility tests .*

##### 82\. ZN FOR AFBs (Tuberculosis Sputum Smear)

* **Clinical Nomenclature**: Acid Fast Bacilli Sputum Smear (Ziehl-Neelsen / Auramine) .  
* **Reporting Format (MoH Scale)**:  
  * Negative: `AFB Negative` (No bacilli seen in 100 high-power fields) .  
  * `Scanty`: Report exact count if 1-9 bacilli are seen in 100 HPFs .  
  * `1+`: 10-99 bacilli in 100 HPFs .  
  * `2+`: 1-10 bacilli per single HPF .  
  * `3+`: \>10 bacilli per single HPF .
* **Clinical Flags**: `Scanty` or `1+ to 3+` results automatically append Abnormal/Critical flags (`H` / `L*`).  
* **HMIS 105 Section 9 Mapping**: Mapped to **Sputum Smear (TB)**: *Section 9: Tested* and *Section 9: Positive* .

##### 83\. Gram Stain

* **Clinical Nomenclature**: Gram Stain Smear Examination .  
* **Reporting Format**: Structured microscopic description:  
  * Standard Negative: `No bacteria seen`.  
  * Standard Positive: Detailed Gram reaction, morphology, and cellular arrangement (e.g., `Gram-negative intracellular diplococci seen`, `Gram-positive cocci in pairs/chains seen`, `Gram-negative rods seen`).
* **Clinical Flags**: Presence of intracellular diplococci or heavy bacterial counts in sterile sites (e.g., CSF) flags as Critical (`*` / `H*`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 84\. Urine Culture & Sensitivity (C&S)

* **Clinical Nomenclature**: Urine Aerobic Culture and Antibiotic Susceptibility .  
* **Reporting Format**: Multi-phase output:  
  * Culture Output: e.g., `No growth after 48 hours of aerobic incubation` OR `Significant growth of Escherichia coli (>= 10^5 CFU/mL)`.  
  * Sensitivity Output: A structured table mapping antimicrobials to:  
    * `S` (Sensitive)  
    * `I` (Intermediate)  
    * `R` (Resistant)
* **Clinical Flags**: Pathogen isolation flags  (`0xE2 0x9A 0xA0`).  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 85\. Blood Culture & Sensitivity (C&S)

* **Clinical Nomenclature**: Blood Culture and Antibiotic Susceptibility .  
* **Reporting Format**:  
  * Culture Output: `No growth after 5 days of aerobic incubation` OR `Significant growth of Staphylococcus aureus`.  
  * Sensitivity Output: Multi-drug susceptibility grid mapping sensitive/resistant patterns.
* **Clinical Flags**: Any positive blood culture represents sepsis and triggers an immediate panic alert (`*` / `H*`).  
* **HMIS 105 Section 9 Mapping**: N/A .

---

### SECTION 7: Blood Transfusion & Immunohematology

*Operates under strict cross-checking protocols to ensure clinical safety prior to blood administration .*

##### 86\. Blood group (ABO & Rh typing)

* **Clinical Nomenclature**: Blood Grouping (ABO / Rhesus Typing) .  
* **Reporting Format**: Combined forward and reverse typing results:  
  * `ABO System`: `A`, `B`, `AB`, or `O` .  
  * `Rhesus System`: `Positive` or `Negative` .  
  * *Example Combined Result*: `O Positive`, `A Negative` .
* **Clinical Flags**: None (purely categorical identification) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 87\. Direct coombs (Direct Antiglobulin Test)

* **Clinical Nomenclature**: Direct Antiglobulin Test (DAT) .  
* **Reporting Options**: `Positive` (stating strength: e.g., `Positive 1+`, `Positive 3+`) or `Negative` .  
* **Clinical Flags**: `Positive` results indicate immune hemolysis (autoimmune hemolytic anemia / hemolytic disease of the newborn) and flag (`0xE2 0x9A 0xA0`) .  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 88\. Indirect coombs (Antibody Screen)

* **Clinical Nomenclature**: Indirect Antiglobulin Test (IAT) .  
* **Reporting Options**: `Positive` or `Negative`.  
* **Clinical Flags**: `Positive` results indicate circulating alloantibodies and flag  (`0xE2 0x9A 0xA0`), preventing immediate compatibility matching.  
* **HMIS 105 Section 9 Mapping**: N/A .

##### 89\. Compatibility Testing (Cross-matching)

* **Clinical Nomenclature**: Major & Minor Cross-match .  
* **Reporting Options**:  
  * `Compatible`: Agglutination absent; blood is safe for transfusion.  
  * `Incompatible`: Agglutination/hemolysis present; **blood is unsafe and MUST NOT be issued**.
* **Clinical Flags**: `Incompatible` results must trigger a critical warning status (`*` / `H*`) to prevent transfusion errors.  
* **HMIS 105 Section 9 Mapping**: N/A .

---

## 3\. Database Schema Implementation Guidelines

To deploy this master test specifications dictionary inside your local SQLite environment:

1. **Table: `test_parameters`**: Store parameters with fields: `id` (1 to 89), `name` (e.g., `Platelets Conut(PLT)`), `department` (e.g., `Hematology`), `unit`, `evaluation_mode` (`DEVICE_PRESET` or `LIMS_EVALUATED`), and `hmis_tag` .  
2. **Table: `reference_ranges`**: Configure rows with `parameter_id`, `sex` (`M`, `F`, `ALL`), `min_age_months`, `max_age_months`, `normal_min` (numeric), `normal_max` (numeric), `panic_min`, and `panic_max` to support automatic software evaluations .  
3. **Flags**: 
4. **Qualitative Matching**: Maintain a secondary lookup table for qualitative string matches to ensure correct clinical evaluation and prevent database entry variations .
