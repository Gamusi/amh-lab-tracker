For a LIMS database to automatically compile monthly reports for your general hospital, each clinical test must map to specific **evaluation algorithms** that decide whether a patient's result increments the **Total Tested** counter, the **Positive** counter, or the **Abnormal** counter in the official HMIS 105 Section 9 format 1, 2\.  
Below is the exact technical data schema and logical mapping rules for the core tests on your laboratory menu.

### 1\. Parasitology & Malaria

For infectious parasites, the report tracks **Total Tested** and **Total Positive** 1\.

#### Malaria Microscopy (Blood Smear \- BS)

* **Reporting Fields**: No. Tested | No. Positive  
* **Result Type**: Qualitative / Text-based  
* **Technical Evaluation Rules**:  
* **Positive Match**: Any text matching \+, \++, \+++, \++++, Positive, MPS Positive, Plasmodium, P. falciparum, or P. vivax  
* **Negative Match**: Any text matching No malaria parasites seen, NMPS, MPS Negative, Negative, NIL, or \-

#### Malaria Rapid Diagnostic Test (mRDT)

* **Reporting Fields**: No. Tested | No. Positive  
* **Result Type**: Qualitative / Text-based  
* **Technical Evaluation Rules**:  
* **Positive Match**: Positive, Reactive, Pos, or \+  
* **Negative Match**: Negative, Non-Reactive, Neg, or \-.

#### Stool Analysis (Microscopy for Ova & Cysts)

* **Reporting Fields**: No. Tested | No. Positive (reporting any active pathogenic parasite as positive)  
* **Result Type**: Qualitative / Text-based  
* **Technical Evaluation Rules**:  
* **Positive Match**: Any specific parasite genus/species name (e.g., E. histolytica cyst, G. lamblia, A. lumbricoides ova, Hookworm ova, Schistosoma mansoni).  
* **Negative Match**: No ova or cysts seen, Normal, NIL, or Negative.

### 2\. Mycobacteriology: Tuberculosis

Like malaria, tuberculosis diagnostics track **Total Tested** and **Total Positive** 1\.

#### Sputum AFB Smear (Z-N or Auramine Stain)

* **Reporting Fields**: No. Tested | No. Positive  
* **Result Type**: Qualitative / Text-based  
* **Technical Evaluation Rules**:  
* **Positive Match**: Any non-zero smear graduation, including 1+, 2+, 3+, Scanty (accompanied by an AFB count), AFB Positive, or Positive  
* **Negative Match**: No Acid Fast Bacilli seen, AFB Negative, Negative, or NIL.

#### GeneXpert (MTB/RIF)

* **Reporting Fields**: No. Tested | No. Positive  
* **Result Type**: Qualitative / Text-based  
* **Technical Evaluation Rules**:  
* **Positive Match**: Any result containing the substring MTB Detected  
* **Negative Match**: MTB Not Detected.  
* **Exception Handling**: Results flagged as Invalid, Error, or No Result must increment a local error log but **must not** count toward Total Tested or Positive in the monthly report.

### 3\. Immunological & Serological Tests

Serology tests track **Total Tested** and **Total Positive** 1\.

#### HIV Rapid Testing (Determine / Stat-Pak / SD Bioline)

* **Reporting Fields**: No. Tested | No. Positive  
* **Result Type**: Qualitative / Text-based  
* **Technical Evaluation Rules**:  
* **Positive Match**: Reactive, Positive, or Pos  
* **Negative Match**: Non-Reactive, Negative, Neg, or \-.  
* *System Guard*: Inconclusive or discrepant results (e.g., Reactive on screening but Non-Reactive on confirmatory) should be logged as Inconclusive for clinical follow-up and excluded from the "Positive" tally until a DNA-PCR or tie-breaker result is verified.

#### Syphilis Screening (VDRL / RPR)

* **Reporting Fields**: No. Tested | No. Positive  
* **Result Type**: Qualitative or Semi-Quantitative (Titers)  
* **Technical Evaluation Rules**:  
* **Positive Match**: Reactive, Positive, or any titer ratio equal to or greater than 1:2 (e.g., 1:2, 1:4, 1:8, 1:16)  
* **Negative Match**: Non-Reactive, Negative, or NIL.

### 4\. Hematology & Blood Transfusion

Hematological tests typically track **Total Tested** and **Total Abnormal** 1\.

#### Hemoglobin (Hb) / Severe Anemia Surveillance

* **Reporting Fields**: No. Tested | No. Abnormal  
* **Result Type**: Quantitative / Numeric  
* **Technical Evaluation Rules**:  
* **Abnormal Definition**: Under MoH epidemiological standards, "Abnormal" for hemoglobin reporting is strictly mapped to **Severe Anemia**, which is defined as a hemoglobin level **strictly less than 8.0 g/dL** (value \< 8.0)  
* **Normal Definition**: Any numeric value value \>= 8.0 is tallied as normal.

#### Blood Grouping & Cross-matching (Transfusion Compatibility)

* **Reporting Fields**: No. Tested only (transfusion compatibility matches do not carry a "Positive" or "Abnormal" column in Section 9\)  
* **Result Type**: Categorical  
* **Technical Evaluation Rules**:  
* **Tally Rules**: Any completed ABO/Rh card (e.g., A Positive, O Negative) or completed cross-match compatibility test (Compatible, Incompatible) simply increments the Total Tested count.

### 5\. Clinical Chemistry

Chemistry parameters track **Total Tested** and **Total Abnormal** 1\.

#### Blood Glucose (Random / Fasting)

* **Reporting Fields**: No. Tested | No. Abnormal  
* **Result Type**: Quantitative / Numeric  
* **Technical Evaluation Rules** (standardized to SI units of mmol/L or converted from mg/dL):  
* **Fasting Blood Sugar (FBS) Abnormal**: Value \< 3.9 mmol/L (Hypoglycemia) OR \> 7.0 mmol/L (Hyperglycemia).  
* **Random Blood Sugar (RBS) Abnormal**: Value \< 3.9 mmol/L OR \> 11.1 mmol/L.

#### Renal & Liver Panels (Creatinine, Urea, ALT, AST)

* **Reporting Fields**: No. Tested | No. Abnormal 3  
* **Result Type**: Quantitative / Numeric  
* **Technical Evaluation Rules**:  
* **The Device-Preset Override**: Because biochemical reference ranges vary significantly by patient age, biological sex, and analyzer calibration, the database should evaluate the **clinical flags** appended directly by the machine:  
* If the result metadata contains a system-appended flag of H (High), L (Low), or \* (Abnormal/Suspect), it automatically increments the **Abnormal** counter.  
* If no machine flag is present, the value is counted as normal.

### 6\. Urinalysis (Chemistry & Microscopy)

#### Urine Protein (Proteinuria / Pre-eclampsia Screening)

* **Reporting Fields**: No. Tested | No. Abnormal  
* **Result Type**: Semi-Quantitative  
* **Technical Evaluation Rules**:  
* **Abnormal Match**: Any dipstick value matching 1+, 2+, 3+, 4+, \+, \++, \+++, \++++, Positive, or Proteinuria  
* **Normal Match**: Trace, Negative, or Nil.

📋 This technical mapping bridges your clinical raw data directly to the HMIS 105 Section 9 data elements, ensuring your system aggregates results accurately without relying on manual calculation.  
📊 Would you like to review how the database should handle "Combined Tests" (such as a multi-parameter Urinalysis dipstick or a Complete Blood Count) so that a single test run doesn't double-count the client in your total monthly tallies?  
