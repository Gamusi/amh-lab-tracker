# Ugandan National Clinical Laboratory Reporting Standards & Parameter Mapping

## Official Guidelines for General (District) Hospitals and Health Center IVs

**Ahmadiyya Muslim Hospital, Mbale, Uganda**  
*Document Ref: AMH-LIMS-REP-STD-2026*  
*In Compliance with: Ministry of Health (MoH) Uganda, NHLDS, ISO 15189:2022, and HMIS 105 Section 9 Guidelines*

---

## 1. Executive Summary & Regulatory Framework

This reporting standard has been compiled to standardize and automate clinical laboratory result reporting at the General (District) Hospital level [622]. Clinical test reporting in Uganda is governed by the Ministry of Health (MoH) and the National Health Laboratory and Diagnostic Services (NHLDS) [621]. Laboratories operating at the General Hospital tier are clinically expected to perform a standard menu of **85 distinct tests and techniques** [622].

To comply with **ISO 15189:2022** and **MoH standards**, every printed or exported laboratory report must strictly maintain a standardized information hierarchy [105, 290, 295, 497]:

1. **Administrative Traceability**: Unique monthly sequential laboratory number, complete client demographics (including age and biological sex), and clinical context (referring clinician and verified-by timestamps) [290, 293, 295].
2. **Dynamic Formatting**: Displaying of relevant diagnostic parameters only (suppressing unperformed tests to eliminate blank spaces, paper waste, and cognitive load) [293, 295].
3. **Clinical Evaluation Metrics**: Direct alignment of quantitative values with standard SI units, age/sex-specific reference intervals, and automated abnormal flags ($H$ for High, $L$ for Low, $*$ for critical/alert values) [290, 295].
4. **Epidemiological Integration**: Automatic translation of client-level raw results into the monthly aggregations mandated by the **HMIS 105 Section 9 (Laboratory Services)** surveillance ledger [624].

---

## 2. Hematology: Complete Blood Count (CBC)

Hematological parameters are generated using automated multi-angle laser flow cytometry or impedance counters [618]. In accordance with the Makerere University clinical audits, automated hematology analyzers must undergo regular quality control (QC) and calibration verification to prevent systematic reporting errors [625]. 

*System Rule (DEVICE_PRESET)*: Raw numeric results and machine-generated flags ($H$, $L$, $*$) must be ingested directly into the client database exactly as transmitted by the analyzer to preserve certified manufacturer calibrations [618].

### CBC Parameter Standard Reference Chart

The following table outlines the standardized reference intervals, reporting units, and clinical classifications for all 22 parameters listed in the hospital's reporting manual [609, 610]:

| Parameter Name               | Standard Unit      | Adult Male Range    | Adult Female Range  | Pediatric Range (<12 Years) | Abnormal Flag Criteria                                |
|:---------------------------- |:------------------ |:------------------- |:------------------- |:--------------------------- |:----------------------------------------------------- |
| **Total WBC Count**          | $10^3/\mu\text{L}$ | $4.0 - 11.0$        | $4.0 - 11.0$        | $6.0 - 14.0$ [610]          | $<4.0$ ($L$) or $>11.0$ ($H$) (Adult)                 |
| **Red Blood Cells (RBC)**    | $10^6/\mu\text{L}$ | $4.50 - 5.90$       | $4.00 - 5.20$ [610] | $4.00 - 5.20$               | Anemia or Polycythemia                                |
| **Hemoglobin (Hb)**          | $\text{g/dL}$      | $13.5 - 17.5$       | $12.0 - 15.5$       | $11.5 - 15.5$ [610]         | **Severe Anemia Watch**: $<8.0\text{ g/dL}$ [23, 624] |
| **Hematocrit (HCT)**         | $\%$               | $41.0 - 50.0$       | $36.0 - 46.0$       | $35.0 - 45.0$ [610]         | Low or High                                           |
| **Mean Cell Volume (MCV)**   | $\text{fL}$        | $80.0 - 100.0$      | $80.0 - 100.0$      | $77.0 - 95.0$ [610]         | Microcytic ($<80.0$) / Macrocytic ($>100.0$)          |
| **Mean Cell Hb (MCH)**       | $\text{pg}$        | $27.0 - 33.0$       | $27.0 - 33.0$       | $23.0 - 31.0$ [610]         | Hypochromic ($<27.0$)                                 |
| **Mean Cell Hb Conc (MCHC)** | $\text{g/dL}$      | $32.0 - 36.0$       | $32.0 - 36.0$       | $28.0 - 33.0$ [610]         | Low or High                                           |
| **Platelets Count (PLT)**    | $10^3/\mu\text{L}$ | $150 - 400$ [610]   | $150 - 400$         | $150 - 400$                 | Thrombocytopenia ($<150$) / Thrombocytosis ($>400$)   |
| **Neutrophils (%)**          | $\%$               | $40.0 - 75.0$       | $40.0 - 75.0$       | $40.0 - 65.0$ [610]         | Relative neutrophilia/neutropenia                     |
| **Lymphocytes (%)**          | $\%$               | $20.0 - 45.0$       | $20.0 - 45.0$       | $19.2 - 49.5$ [610]         | Relative lymphocytosis/lymphopenia                    |
| **Monocytes (%)**            | $\%$               | $2.0 - 10.0$        | $2.0 - 10.0$        | $4.5 - 12.1$ [610]          | Relative monocytosis                                  |
| **Eosinophils (%)**          | $\%$               | $1.0 - 6.0$         | $1.0 - 6.0$         | $1.0 - 12.0$ [610]          | Relative eosinophilia                                 |
| **Basophils (%)**            | $\%$               | $0.0 - 1.0$ [610]   | $0.0 - 1.0$         | $0.0 - 1.0$                 | Relative basophilia                                   |
| **Neutrophils (Absolute)**   | $10^9/\mu\text{L}$ | $2.00 - 7.50$       | $2.00 - 7.50$       | $2.00 - 6.00$ [610]         | Absolute neutropenia ($<1.5$)                         |
| **Lymphocytes (Absolute)**   | $10^9/\mu\text{L}$ | $1.00 - 4.00$       | $1.00 - 4.00$       | $5.00 - 8.50$ [610]         | Lymphopenia or Lymphocytosis                          |
| **Monocytes (Absolute)**     | $10^9/\mu\text{L}$ | $0.20 - 0.80$       | $0.20 - 0.80$       | $0.70 - 1.50$ [610]         | Absolute monocytosis ($>0.8$)                         |
| **Eosinophils (Absolute)**   | $10^9/\mu\text{L}$ | $0.04 - 0.40$       | $0.04 - 0.40$       | $0.30 - 0.80$ [610]         | Absolute eosinophilia ($>0.5$)                        |
| **Basophils (Absolute)**     | $10^9/\mu\text{L}$ | $0.00 - 0.10$       | $0.00 - 0.10$       | $0.00 - 0.50$ [610]         | Absolute basophilia ($>0.2$)                          |
| **RDW (%)**                  | $\%$               | $11.0 - 16.0$ [610] | $11.0 - 16.0$       | $11.0 - 16.0$               | Anisocytosis ($>16.0$)                                |
| **Thrombocrit (PCT)**        | $\%$               | $0.16 - 0.33$ [610] | $0.16 - 0.33$       | $0.16 - 0.33$               | Thrombocytopenia or Thrombocytosis                    |
| **MPV**                      | $\text{fL}$        | $6.0 - 10.0$ [610]  | $6.0 - 10.0$        | $6.0 - 10.0$                | Giant platelets warning                               |
| **PDW (%)**                  | $\%$               | $12.0 - 18.0$ [610] | $12.0 - 18.0$       | $12.0 - 18.0$               | High platelet size variability                        |

---

## 3. Serology & Clinical Immunology

Serological tests at General Hospitals primarily consist of qualitative, rapid lateral-flow assays and semi-quantitative agglutination or titer-based tests [622].

### HIV Rapid Diagnostic Testing (MoH Three-Test Algorithm)

* **Standard Nomenclature**: HIV Rapid Test [15, 623].
* **Methodology / Kits**: **Determine** (Screening) $\rightarrow$ **Stat-Pak** (Confirmatory) $\rightarrow$ **SD Bioline** (Tie-breaker) [15, 623].
* **Reporting Options**: 
  * `Reactive`: Confirmed positive across the algorithm. Must trigger counseling and referral [15].
  * `Non-Reactive`: Negative on screening [15].
  * `Inconclusive`: Discrepant results between screening and confirmatory with a negative/discrepant tie-breaker.
* **HMIS 105 Mapping**: Counts toward *Section 9: Total Tested* and *Total Positive*, disaggregated strictly by age band and biological sex [623, 624].

### Malaria Rapid Diagnostic Test (mRDT)

* **Standard Nomenclature**: Malaria Rapid Diagnostic Test [622].
* **Methodology**: HRP2-based (for *P. falciparum*) rapid immunochromatographic assay [23].
* **Reporting Options**: `Positive` or `Negative` [15].
* **HMIS 105 Mapping**: Reported under *Section 9: Malaria RDT* [23].

### Syphilis Screening (VDRL / RPR)

* **Standard Nomenclature**: VDRL (Venereal Disease Research Laboratory) / RPR (Rapid Plasma Reagin) [622].
* **Methodology**: Flocculation agglutination assay [622].
* **Reporting Options**:
  * `Non-Reactive`: Standard negative response.
  * `Reactive`: Must be reported alongside a serial dilution titer ratio (e.g., `Reactive 1:8`, `Reactive 1:16`, `Reactive 1:64`) to guide clinical management and therapy tracking [23].
* **HMIS 105 Mapping**: Reported under *Section 9: Syphilis Tested & Syphilis Positive* [23].

### Typhoid Serology (Widal Test)

* **Standard Nomenclature**: Widal Agglutination [610].
* **Methodology**: Slide/tube agglutination measuring Salmonella O and H antigens [622].
* **Reporting Options**: Reported as reciprocal titers for both antigens (e.g., `TO 1:80`, `TH 1:160`, `AO 1:40`, `AH 1:80`).
  * *Standard Interpretive Threshold*: Titers $\ge 1:160$ for O or H antigens are flagged as **Abnormal/Significant** in endemic areas.

### Hepatitis B Surface Antigen (HBsAg)

* **Standard Nomenclature**: Hepatitis B Surface Antigen [622].
* **Methodology**: Rapid immunochromatographic lateral flow.
* **Reporting Options**: `Positive` or `Negative` [15]. Successful linkage to care is mandated for positive patients [23].

### Rheumatoid Factor (RF) & Brucella Agglutination Test (BAT)

* **Standard Nomenclature**: Rheumatoid Factor (RF) / Brucella Agglutination Test (BAT) [610].
* **Methodology**: Latex agglutination / slide agglutination [622].
* **Reporting Options**: `Positive` or `Negative` (alternatively `Reactive` / `Non-Reactive`). BAT should report specific antibody titers if reactive (e.g., `Reactive 1:160`).

### Pregnancy Testing (HCG Urine / HCG Blood)

* **Standard Nomenclature**: HCG Urine / HCG Blood [610].
* **Methodology**: Rapid lateral-flow strip (Urine) / Quantitative ELISA (Blood) [622].
* **Reporting Options**:
  * *Urine*: `Positive` or `Negative`.
  * *Blood*: Quantitative concentration in $\text{mIU/mL}$. Reference range: `<5.0\text{ mIU/mL}` (Negative) / $\ge 25.0\text{ mIU/mL}$ (Positive).

### Helicobacter pylori (H. pylori Antigen & Antibody)

* **Standard Nomenclature**: H. pylori Antigen / H. pylori Antibody [610].
* **Methodology**: Stool monoclonal antibody lateral-flow (Antigen) / Serum lateral-flow (Antibody) [610].
* **Reporting Options**: `Positive` or `Negative` [610].

### Sputum Tuberculosis LAM (TB-LAM)

* **Standard Nomenclature**: Urine Lipoarabinomannan (TB-LAM) [610].
* **Methodology**: Rapid lateral flow assay utilizing urine samples for severely immunocompromised HIV-positive clients.
* **Reporting Options**: `Positive` or `Negative` (graded intensity from $1+$ to $4+$ may be included local-use).

---

## 4. Biochemistry & Coagulation

Biochemistry tests generate quantitative values and require strict control over baseline ranges, instrument calibration, and sample preparation [625].

### Fasting Blood Sugar (FBS) & Random Blood Sugar (RBS)

* **Standard Nomenclature**: Fasting Blood Sugar / Random Blood Sugar [610].
* **Standard Unit**: $\text{mmol/L}$ (SI Unit standard) [610].
* **Conversion Factor**: $\text{mg/dL} \div 18.018 = \text{mmol/L}$.
* **Reporting and Reference Ranges**:

| Parameter | standard Unit   | Normal Range | Borderline Range | Diabetic Threshold | Abnormal Flag Criteria          |
|:--------- |:--------------- |:------------ |:---------------- |:------------------ |:------------------------------- |
| **FBS**   | $\text{mmol/L}$ | $3.9 - 5.5$  | $5.6 - 6.9$      | $\ge 7.0$          | $<3.9$ ($L$) or $\ge 5.6$ ($H$) |
| **RBS**   | $\text{mmol/L}$ | $3.9 - 7.8$  | $7.9 - 11.0$     | $\ge 11.1$ [610]   | $<3.9$ ($L$) or $\ge 7.9$ ($H$) |

### Activated Partial Thromboplastin Time (APTT)

* **Standard Nomenclature**: APTT [610].
* **Methodology**: Automated optical or mechanical clot detection [622].
* **Standard Unit**: Seconds [610].
* **Reference Range**: $25.0 - 35.0\text{ seconds}$. Values $>35.0\text{ seconds}$ are flagged as High ($H$).

---

## 5. Urinalysis

Urinalysis is a multi-parameter profile split into physical macropathology, chemical dipstick chemistry, and microscopic sediment analysis [610].

### A. Urinalysis Macroscopy

* **Appearance / Turbidity**: Reported as `Clear`, `Slightly Turbid`, or `Turbid` [610].
* **Color**: Reported as `Straw`, `Yellow` [610], `Amber`, `Red` (indicating hematuria), or `Brown` (indicating bilirubinuria).

### B. Urinalysis Dipstick Chemistry

All dipstick parameters must be reported semi-quantitatively using standardised terminology rather than raw color scales [257]:

* **Specific Gravity (S.G.)**: Numeric range [$1.005 - 1.030$] [610].
* **pH**: Numeric scale [$5.0 - 8.5$] [610].
* **Proteins**: `Nil` [610], `Trace`, `1+` (approx. $30\text{ mg/dL}$), `2+` (approx. $100\text{ mg/dL}$), `3+` (approx. $300\text{ mg/dL}$), or `4+` (approx. $\ge 1000\text{ mg/dL}$). Any finding $\ge 1+$ is flagged as Abnormal [610].
* **Glucose**: `Nil` [610], `Trace`, `1+`, `2+`, `3+`, `4+`. Any finding $\ge 1+$ is flagged as Abnormal [610].
* **Bilirubin**: `Nil` [610], `1+`, `2+`, `3+`. Any non-zero finding is flagged as Abnormal [610].
* **Urobilinogen**: `Normal` (or `0.2 EU/dL`), `1+`, `2+`, `3+`. Any finding $\ge 1+$ is flagged as Abnormal.
* **Ketones**: `Nil` [610], `Trace`, `1+`, `2+`, `3+`. Any non-zero finding is flagged as Abnormal.
* **Blood**: `Nil` [610], `Trace`, `1+`, `2+`, `3+`. Any non-zero finding is flagged as Abnormal.
* **Nitrites**: `Positive` or `Negative` (Nil) [610].
* **Leukocytes (Leukocyte Esterase)**: `Nil`, `Trace`, `1+`, `2+` [610], `3+`. Any finding $\ge 1+$ is flagged as Abnormal.

### C. Urinalysis Microscopy (Sediment Analysis)

* **Pus Cells (WBCs)**: Reported as number of cells per high-power field (e.g., `0-2 / hpf`, `Pus cells (++) / lpf` [610], `10-15 / hpf`). *Clinical Normal*: $<5\text{ WBCs/hpf}$.
* **Red Blood Cells (RBCs)**: Reported as number of cells per high-power field (e.g., `0-1 / hpf`, `5-10 / hpf`). *Clinical Normal*: $<3\text{ RBCs/hpf}$.
* **Epithelial Cells**: Reported semi-quantitatively as `Few`, `Moderate`, or `Plenty`.
* **Casts & Crystals**: Specifically identified by type if present (e.g., `Calcium oxalate crystals (++)`, `Hyaline casts (0-1 / lpf)`, `Triple phosphate crystals`).

---

## 6. Parasitology & Microbiology

### Parasitology: Blood Smear for Malaria Parasites (MPS)

* **Standard Nomenclature**: Blood Smear MPS / Malaria Microscopy [610].
* **Methodology**: Thick and thin peripheral blood smears stained with Giemsa stain [622].
* **Reporting Options**:
  * `No malaria parasites seen` (NMPS) [23].
  * `Positive`: Must be reported semi-quantitatively on the standard plus system ($1+$ to $4+$) or quantified as density (parasites/$\mu\text{L}$ of blood) [23].
    * $1+$ ($1 - 10$ parasites per $100$ thick-film fields).
    * $2+$ ($11 - 100$ parasites per $100$ thick-film fields).
    * $3+$ ($1 - 10$ parasites per single thick-film field).
    * $4+$ ($>10$ parasites per single thick-film field).
  * **Species Identification**: Thin smear must be reviewed to identify species (e.g., *Plasmodium falciparum*, *Plasmodium vivax*).

### Parasitology: Stool Analysis (Macroscopy & Microscopy)

* **Standard Nomenclature**: Stool Analysis [610].
* **Macroscopy**:
  * *Consistency*: `Formed`, `Semi-formed`, `Loose`, or `Watery`.
  * *Composition*: Presence or absence of `Blood`, `Mucus`, or `Adult worms` (e.g., *Ascaris lumbricoides*).
* **Microscopy (Ova, Cysts & Trophozoites)**:
  * *Pathogens*: Specifically reported by genus and species (e.g., `E. histolytica cysts`, `G. lamblia cysts`, `Hookworm ova`, `Schistosoma mansoni ova`, `A. lumbricoides ova`).
  * *Direct Wet Mounts*: Reported as `Positive` (stating species) or `No ova, cysts, or vegetative forms seen`.

### Sputum ZN Stain for Acid-Fast Bacilli (AFB)

* **Standard Nomenclature**: ZN for AFBs [610].
* **Methodology**: Ziehl-Neelsen carbolfuchsin staining of sputum smears [622].
* **Reporting Scale (MoH National standard)**:
  * `AFB Negative`: No Acid-Fast Bacilli seen in 100 high-power fields [23].
  * `Scanty`: $1 - 9$ AFB in 100 high-power fields (report the exact number of bacilli counted).
  * `1+`: $10 - 99$ AFB in 100 high-power fields [23].
  * `2+`: $1 - 10$ AFB per single high-power field.
  * `3+`: $>10$ AFB per single high-power field.

### Blood Grouping

* **Standard Nomenclature**: Blood Group [610].
* **Methodology**: Slide or tube agglutination testing both forward grouping (monoclonal anti-A, anti-B, anti-D) and reverse/serum grouping [622].
* **Reporting Formats**:
  * *ABO System*: `A`, `B`, `AB`, or `O` [610].
  * *Rhesus System*: `Positive` or `Negative` [610].
  * *Example Combo*: `O Positive` or `A Negative`.

### Erythrocyte Sedimentation Rate (ESR)

* **Standard Nomenclature**: E.S.R [610].
* **Methodology**: Westergren method [622].
* **Standard Unit**: $\text{mm/hour}$ [622].
* **Adult Male Reference Range**: $<15\text{ mm/hr}$ ($0-50$ years) / $<20\text{ mm/hr}$ ($>50$ years).
* **Adult Female Reference Range**: $<20\text{ mm/hr}$ ($0-50$ years) / $<30\text{ mm/hr}$ ($>50$ years).

### Coagulation: Direct Coombs Test

* **Standard Nomenclature**: Direct Coombs Test [610].
* **Methodology**: Direct Antiglobulin Test (DAT) utilizing polyspecific antihuman globulin reagent [622].
* **Reporting Options**: `Positive` or `Negative` (optionally graded $1+$ to $4+$ to represent agglutination strength).

### COVID-19 Rapid Diagnostic Test

* **Standard Nomenclature**: COVID-19 RDT [610].
* **Methodology**: Lateral-flow antigen assay [610].
* **Reporting Options**: `Positive` or `Negative`.

### immunology: CD4/CD8 Count

* **Standard Nomenclature**: CD4 Count [610].
* **Methodology**: Single-platform flow cytometry [622].
* **Standard Unit**: Cells/$\mu\text{L}$ [610].
* **Adult Reference Range**: $500 - 1500\text{ cells/}\mu\text{L}$.
  * *Clinical Threshold (Immunosuppression)*: Counts $<350\text{ cells/}\mu\text{L}$ are flagged as Low ($L$).
  * *Clinical Threshold (Advanced Disease)*: Counts $<200\text{ cells/}\mu\text{L}$ are flagged with critical status ($*$) indicating high risk for opportunistic pathogens.

### Cryptococcal Antigen (CrAg)

* **Standard Nomenclature**: CrAg [610].
* **Methodology**: Lateral flow assay (LFA) utilizing serum, plasma, or cerebrospinal fluid (CSF) [610, 622].
* **Reporting Options**: `Positive` or `Negative`.

---

## 7. Dynamic Reference Range Matrix

The system's database schema maps the following biological reference ranges dynamically [290]. Reference ranges must shift automatically based on the Patient's **Age** and **Biological Sex** entered in the administrative header to prevent diagnostic errors [290, 610]:

```
                     [Raw Test Value Entered]
                                ||
                                \/
                  [System Looks up Sex & Age]
                                ||
                                \/
         +-----------------------------------------------+
         |     Is Patient Adult Male? (M, >=12Y)         | -> Use Adult Male Ranges
         |     Is Patient Adult Female? (F, >=12Y)       | -> Use Adult Female Ranges
         |     Is Patient Pediatric? (<12Y)              | -> Use Pediatric Ranges
         +-----------------------------------------------+
                                ||
                                \/
                     [Evaluate Value vs. Range]
                                ||
         +----------------------+-----------------------+
         ||                                            ||
         \/                                            \/
    [Value is within range]                  [Value is out of range]
         ||                                            ||
         \/                                            \/
     [Flag = NULL]                             [Apply Flag: H / L]
```

This automated, meta-mapped evaluation logic ensures that any clinic or hospital deploying the **AMH Lab Tracker** can provide standard-compliant, clinically precise diagnostic reports, bridging local clinical work with national public health needs [624, 626].
