# Clinical Laboratory Analyzer Integration Blueprint
## Intercepted File & Database Exchange Specification
**Ahmadiyya Muslim Hospital (AMH) — Mbale, Uganda**

---

### 1. Executive Summary & Design Philosophy
Integrating clinical diagnostic analyzers with a Laboratory Information Management System (LIMS) is critical for eliminating manual data transcription errors, optimizing turnaround times (TAT), and ensuring absolute data integrity [622]. 

At Ahmadiyya Muslim Hospital, several automated analyzers—including the calibrated hematology and chemistry systems—are installed alongside proprietary desktop applications provided by equipment suppliers [user query, 586]. These existing supplier apps interact directly with the instruments over physical serial COM ports (RS-232) and write raw test results into a local database (such as a local SQLite instance) [user query, 615, 616]. 

To respect and preserve these manufacturer-validated environments, the **AMH Lab Tracker** utilizes a **Non-Intrusive Interception Integration** pattern. Instead of hijacking physical COM ports or replacing the supplier-provided interface, the AMH Lab Tracker acts as a read-only secondary consumer [user query]. It monitors and harvests data directly from the supplier app's local SQLite database files or file-system hot folders, enabling seamless analytical tracking, reporting, and HMIS statistical aggregation while leaving the supplier's certified printing and testing workflows entirely undisturbed [user query, 451].

---

### 2. Integration Typologies

Standard LIMS interfaces typically connect via direct Serial (RS-232), TCP/IP socket servers, or specialized middleware [584, 615, 616, 619]. For the offline-first, shared-hardware constraints of AMH, two non-intrusive integration typologies are specified:

```
[ Clinical Analyzer ] 
         │ (COM Port / RS-232) [615, 616]
         ▼
[ Supplier Software ] ──(Writes Raw Data)──► [ Supplier SQLite DB / Folder ]
                                                     │ (Read-Only Interception)
                                                     ▼
                                            [ AMH Lab Tracker Backend ]
```

#### Typology A: SQLite Interception Bridge (Primary)
When the supplier app captures data via serial COM ports and writes it directly to a local SQLite database [user query, 616]:
*   **The Bridge Mechanism**: The AMH Lab Tracker backend spawns an isolated read-only thread that periodically attaches to the supplier app's database using SQLite's shared connection protocols.
*   **Zero-Interference Protocol**: To guarantee that the AMH Lab Tracker never blocks, locks, or corrupts the supplier's database, the connection is established with strict safety flags:
    *   `PRAGMA query_only = ON;` (Forces the connection to be read-only at the database engine level).
    *   `PRAGMA busy_timeout = 5000;` (Prevents query freezes by waiting up to 5000ms if the supplier app is actively writing).
*   **Data Harvesting**: A background daemon queries the supplier's results table (filtering for records logged since the last sync timestamp) and maps parameters (e.g., RBC, WBC, Hb, Platelets) straight into the AMH Lab Tracker's `test_results` schema.

#### Typology B: Hot-Folder File Exchange (Secondary / File-Based)
For analyzers that support direct output to files (CSV, TXT, XML, or Excel) rather than a database [617]:
*   **The Exchange Mechanism**: The supplier software is configured to export raw results directly to a designated local "Hot Folder" directory on the PC [617].
*   **Directory Polling Daemon**: The AMH Lab Tracker backend runs a filesystem watcher (using Python's `watchdog` library or a lightweight polling loop) that scans the directory every 5 seconds.
*   **Safe-Ingest Pipeline**:
    1.  **Detection**: A new file is detected (e.g., `result_10293.txt`).
    2.  **Lock Verification**: The daemon attempts to open the file with write-access. If it fails, the file is still being written by the analyzer/supplier app; the daemon backs off and waits.
    3.  **Parsing**: Once the file is released, Python's built-in libraries parse the plain-text/structured data (using Regular Expressions for raw text or `csv.DictReader` for comma-separated data) [581].
    4.  **Ingestion & Auto-Tally**: Numeric values are written to `test_results`, and positive surveillance cases (such as malaria or critical counts) are automatically registered in the epidemiological ledger [451, 558].
    5.  **Archival**: To prevent duplicate processing and keep the folder clean, the ingested file is moved to a local `/archive` subdirectory.

---

### 3. Preserving Onboard Calibration & Native Flags

Under international clinical standards (such as **ISO 15189:2022** and **ISO 17025**), maintaining the metrological traceability and physical calibration of testing equipment is a strict quality requirement [473, 499]. When diagnostic machines are professionally calibrated by third-party engineers (e.g., Biotech), the instrument's internal computer calculates complex curves and appends diagnostic "flags" directly to the result output [user query, 586]:

*   **Flags & Suspect Tags**: These include mathematical outliers (`H` for high, `L` for low), alert values, or suspect morphology markers (`*`, `WBC Alarm`, etc.) [586].
*   **The Invalidation Risk**: If a LIMS attempts to recalculate reference ranges and override these hardware-generated flags, it risks invalidating the vendor-certified calibration of the physical machine [user query].
*   **Unified Mapping Schema**: The database schema explicitly segregates results based on their origin:

| Column | Type | Description |
| :--- | :--- | :--- |
| `evaluation_mode` | `TEXT` | Must be either `'DEVICE_PRESET'` or `'LIMS_EVALUATED'` [587]. |
| `raw_device_flags` | `TEXT` | Stores the exact, unmodified character flags generated by the physical analyzer (e.g., `'H*'`, `'L'`, `'None'`) [586]. |

*   **Execution Logic**:
    *   **For Analyzer Imports (`DEVICE_PRESET`)**: The AMH Lab Tracker imports the numeric result and the `raw_device_flags` exactly as-is from the SQLite database or hot folder [587]. No LIMS-side mathematical evaluations are applied. The final printed report displays the analyzer's native flag alongside the result, preserving the calibrated output exactly as the manufacturer intended [user query].
    *   **For Manual Entry (`LIMS_EVALUATED`)**: For rapid tests or manual assays (e.g., malaria microscopy or urinalysis), the LIMS dynamically evaluates the entered numbers against the database-stored, age-and-sex-specific reference ranges and appends appropriate system-calculated flags [203, 587].

---

### 4. Technical Specifications for Database Interception

For supplier applications utilizing a local database, the extraction process is implemented via a lightweight, zero-dependency Python bridge integrated within the FastAPI backend architecture.

```python
import sqlite3
import logging
from datetime import datetime

# Configure logging to monitor integration health
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("analyzer_integration")

SUPPLIER_DB_PATH = "C:/Program Files/SupplierApp/data/results.db"
AMH_DB_PATH = "data/amh_lab.db"

def extract_latest_device_results(last_sync_timestamp: str):
    """
    Connects to the supplier's SQLite database in strict read-only mode,
    extracting results generated since the last synchronized record.
    """
    if not os.path.exists(SUPPLIER_DB_PATH):
        logger.warning("Supplier database file not found. Analyzer integration offline.")
        return []

    # Open connection using loopback loop and read-only URI configuration
    try:
        uri_path = f"file:{SUPPLIER_DB_PATH}?mode=ro"
        conn = sqlite3.connect(uri_path, uri=True, timeout=5.0)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        
        # Execute query selecting results matching hematology parameters
        query = """
            SELECT sample_id, test_date, parameter_name, value, unit, flags 
            FROM device_results 
            WHERE test_date > ? 
            ORDER BY test_date ASC
        """
        cur.execute(query, (last_sync_timestamp,))
        records = cur.fetchall()
        
        results = [dict(row) for row in records]
        cur.close()
        conn.close()
        return results
        
    except sqlite3.OperationalError as e:
        logger.error(f"Failed to read supplier DB due to lock or permission issues: {e}")
        return []
```

---

### 5. Quality & Interoperability Compliance

By implementing this non-intrusive file/database exchange framework, the laboratory achieves full technical compliance with modern international standards:

1.  **Data Integrity (ISO 15189 Clause 8.9)**: Ingesting data directly from local files or databases completely removes manual transcription errors (double-keying typos, value transposition), ensuring the reported result matches the tested sample with 100% accuracy [175, 473, 622].
2.  **Audit Trail Accountability (21 CFR Part 11)**: Every automated result import is logged in the `audit_log` table with the user stamp `'SYSTEM_INTEGRATION'` and the unique `sample_id` issued by the analyzer, allowing regulators to reconstruct the exact workflow lifecycle of the sample [3, 8, 451].
3.  **Interoperability Foundations**: Storing parameters in flat, normalized relational fields under the unified `clients` database design provides the exact structured framework needed to easily export diagnostic data as standard JSON, CSV, or HL7 message segments in the future [user query, 364, 451].
