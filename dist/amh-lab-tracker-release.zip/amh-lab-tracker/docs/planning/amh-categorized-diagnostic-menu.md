# AMH Categorized Diagnostic Menu

**Ahmadiyya Muslim Hospital, Mbale, Uganda**

---

## Executive Summary & Regulatory Framework

This document defines the structured, departmentally grouped laboratory test menu for the **AMH Lab Tracker**. This catalog used the official **Ministry of Health (MoH)** and **National Health Laboratory and Diagnostic Services (NHLDS)** standard menu of **85 tests and techniques** designated for General (District) Hospitals in Uganda .

---

## Laboratory Departmental Grouping Matrix

The entire 85-test diagnostic menu is partitioned below into **seven operational sections** of the laboratory.

---

### 1. Hematology

This section is governed by automated Complete Blood Count (CBC) analyzer outputs and manual slide-reading protocols and other analyses.

#### A. CBC TESTS

1. **Total WBC Count**
2. **Red Blood Cells(RBC)**
3. **Hemoglobin(Hb)** 
4. **Hematocrit(HCT)**
5. **Mean CellVolume(MCV)**
6. **Mean Cell Hb..(MCH)**
7. **Mean Cell Hb.Conc.(MCHC)**
8. **Platelets Count(PLT)** **
9. **Neutrophils (%)** *(Relative count)*
10. **Lymphocytes (%)** *(Relative count)*
11. **Monocytes (%)** *(Relative count)*
12. **Eosinophils (%)** *(Relative count)*
13. **Basophils (%)** *(Relative count)*
14. **Neutrophils (10^9/µL)** *(Absolute count)*
15. **Lymphocytes (10^9/µL)** *(Absolute count)*
16. **Monocytes (10^9/µL)** *(Absolute count)*
17. **Eosinophils (10^9/µL)** *(Absolute count)*
18. **Basophils (10^9/µL)** *(Absolute count)*
19. **RBC Distribution width** 
20. **Thrombocrit(PCT)**
21. **Mean Platelet Volume(MPV)**
22. **PLT Distribution Width**

#### B. OTHERS

23. **E.S.R** *(Erythrocyte Sedimentation Rate)*

24. **Aptt** *(Activated Partial Thromboplastin Time - Coagulation panel)

25. **Prothrombin Time (PT)** *(Essential companion to Aptt for bleeding disorders)*

26. **International Normalized Ratio (INR)** *(Calculated coagulation index)*

27. **Bleeding Time (BT)** *(Manual primary hemostasis test)*

28. **Clotting Time (CT)** *(Manual whole-blood clotting assessment)*

29. **Reticulocyte Count** *(Manual slide check for bone marrow red cell production)*

30. **Sickling Test (Sodium Metabisulfite)** *(Frontline sickle-cell disease screening)*

NOTE: Even though CBC results should be captured in the tracker as one single unit, each individual parameter must be recorded as captured by the analyzer. The performance report should report how many CBCs done in a given period and not how many of each parameter on a CBC were done.

---

### 2. Serology & Clinical Immunology

This department handles lateral-flow rapid diagnostic tests (RDTs), agglutination assays, and basic biomarker screening.

#### A. Routine.

31. **WIDAL** *(Salmonella typhi slide/tube agglutination)*
32. **VDRL/RPR** *(Syphilis screening and titer dilution)*
33. **HIV** *(Determine/Stat-Pak/SD Bioline national rapid algorithm)*
34. **HBsAg** *(Hepatitis B Surface Antigen rapid screen)*
35. **BAT** *(Brucella Antigen Test - slide agglutination)*
36. **RF** *(Rheumatoid Factor latex agglutination)*
37. **HCG Urine** *(Urine qualitative pregnancy check)*
38. **HCG Blood** *(Serum qualitative pregnancy check)*
39. **H.Pylori Ag** *(Stool antigen rapid lateral flow)*
40. **H.Pylori Ab** *(Serum antibody rapid lateral flow)*
41. **Malaria RDT** *(Histidine-Rich Protein II lateral flow)*
42. **TB LAM** *(Lipoarabinomannan urine lateral flow)*
43. **COVID19RDT** *(SARS-CoV-2 antigen rapid test)*
44. **CD4   COUNT** *(Flow cytometry / Point-of-Care CD4 T-cell count)*
45. **CrAg** *(Cryptococcal Antigen lateral flow for CSF/Serum)*

#### B. Others

46. **HCV Ab (Hepatitis C Virus)** *(Rapid antibody screening)*
47. **TPHA (Treponema Pallidum Hemagglutination Assay)** *(Confirmatory syphilis test)*
48. **ASO Titer (Anti-Streptolysin O)** *(Agglutination check for post-streptococcal sequelae)*
49. **Alpha-Fetoprotein (AFP)** *(Oncology tumor marker)*

---

### 3. Clinical Biochemistry

Covers basic glucometry to comprehensive liver, renal, and metabolic profiles run on semi-automated/automated spectrophotometers.

#### A. Glucometer (done with whole blood)

50. **FBS** *(Fasting Blood Sugar)*
51. **RBS** *(Random Blood Sugar)*

#### B. Panels

##### (i) RFTs

52. **Serum Creatinine** *(Essential renal function test)*

53. **Serum Urea** *(Renal waste product clearance)*

54. **Serum Uric Acid** *(Metabolic gout marker)*

    **(ii) LFTs**

55. **ALT / SGPT** *(Alanine Aminotransferase - Core liver function)*

56. **AST / SGOT** *(Aspartate Aminotransferase - Core liver function)*

57. **Alkaline Phosphatase (ALP)** *(Cholestatic liver/bone marker)*

58. **Total Bilirubin** *(Biliary/hepatic clearance)*

59. **Direct Bilirubin** *(Conjugated bilirubin fraction)*

60. **Total Protein** *(Synthetic liver function/nutritional marker)*

61. **Serum Albumin** *(Synthetic liver function)*

    **(iii) Cardiac** 

62. **Total Cholesterol** *(Cardiovascular lipid screening)*

    **(iv) Electrolyte**

63. **Serum Potassium (K+)** *(Electrolyte panel)*

64. **Serum Sodium (Na+)** *(Electrolyte panel)*

65. **Serum Chloride (Cl-)** *(Electrolyte panel)*

Each panel, just like CBC, is tracked as a single test, but reported in detail. using a table.

---

### C. Urinalysis

Standardized urine examination is split between macroscopic observation, multi-parameter dry chemistry strip evaluation, and microscopic sediment checking.

#### **Macroscopy** *(Color, Appearance, Clarity)*

66. **Microscopy** *(Casts, Crystals, Epithelial Cells, Pus Cells/lpf)*
67. **Urobilinogen**
68. **Glucose**
69. **Bilirubin**
70. **Ketones**
71. **S.G** *(Specific Gravity)*
72. **Blood**
73. **PH** *(Urine pH value)*
74. **Proteins** *(Proteinuria screening)*
75. **Nitrates** *(Nitrite detection)*
76. **Leukocytes** *(Leukocyte Esterase)*

urinalysis, similar to CBC, is tracked as a single test, but reported in detail for all parameters. using a table showing parameter and result.

urinalysis should always be the last test on the print out report given to the client.

---

### 5. Parasitology

This section covers manual microscopic detection of intestinal, tissue, and blood parasites .

78. **Blood smear for  Malaria Parasites** *(Malaria Parasites Seen - Blood smear thick/thin gold standard)*

79. **Stool Analysis (Macroscopy)** *(Consistency, Blood, Mucus, Worms)* and

80. **Stool Analysis (Microscopy)** *(Ova, Cysts, Trophozoites, Larvae)*

81. **Stool Occult Blood** *(Guaiac or immunological fecal occult blood test)*

stool analysis, similar to CBC, is tracked as a single test. for both microscopy and macroscopy. but reported in details. using a table.

---

### 6. Microbiology

This critical department is responsible for identifying bacterial and mycobacterial pathogens and testing antimicrobial susceptibility.

82. **ZN  FOR AFBs** *(Ziehl-Neelsen acid-fast bacilli stain for Tuberculosis)*

83. **Gram Stain (Urine, Pus, CSF)** *(Manual smear classification)*

84. **Urine Culture & Sensitivity (C&S)** *(Aerobic bacterial isolation and AST)*

85. **Blood Culture & Sensitivity (C&S)** *(Sepsis pathogen isolation and AST)*

---

### 7. Blood Transfusion & Immunohematology

This section holds the ultimate safety responsibility for patient compatibility prior to blood transfusions.

86. **Blood Grouping** *(ABO typing and Rhesus Antigen)*

    **<u>compatibility testing/crossmatching;</u>**

87. **Direct coombs** *(Direct Antiglobulin Test)*

88. **Indirect coombs** *(Indirect Antiglobulin Test for antibody screening)*

89. **Compatibility Testing (Cross-matching)** *(Major and minor compatibility check)*

---

Tests that are under surveillance for positives shall be configured manually.
